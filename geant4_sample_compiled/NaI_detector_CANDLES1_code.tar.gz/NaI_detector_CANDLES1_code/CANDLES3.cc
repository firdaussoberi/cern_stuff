// source: $G4INSTALL/examples/novice/N03/exampleN03.cc
// source: $G4INSTALL/examples/examples/extended/analysis/AnaEx02/AnaEx02.cc
// 2014/05/12 K.Nakajima
//
#include "G4RunManager.hh"
#include "G4UImanager.hh"

#include "Randomize.hh"

#include "CAN3DetectorConstruction.hh"
#include "CAN3PrimaryGeneratorAction.hh"
#include "CAN3RunAction.hh"
#include "CAN3EventAction.hh"
#include "CAN3SteppingAction.hh"
#include "CAN3HistoManager.hh" // for root output


#include "Shielding.hh" // PhysicsList
#include "QGSP_BERT_HP.hh"
#include "QGSP_BIC_HP.hh"

#ifdef G4VIS_USE
#include "G4VisExecutive.hh"
#endif

#ifdef G4UI_USE
#include "G4UIExecutive.hh"
#endif

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

int main(int argc,char** argv)
{
  //---------------------------------------------------------------------------------//
  G4int mcType = -1;
  G4String rootFileName   = "hoge.root";
  
  if (argc == 1 || 2 < argc){
    mcType = atoi(argv[2]);
    if (argc == 4 && mcType == 0) {
      G4cout << "Monochromatic beam mode" << G4endl;
    }
    else if (argc == 4 && mcType == 1) {
      G4cout << "GPS mode" << G4endl;
    }
   // else if (argc == 2) {
   // G4cout << "Geometry mode" << G4endl;
   // }
    else {
      G4cerr << G4endl
   
    //if (argc == 1 || 3 < argc) {
	     << "---------------------------------------------------"                                                     << G4endl
	     << "MCType = 0: Monochromatic beam mode"                                                                     << G4endl
	     << " Usage: " << argv[0] << " InputMacro MCType OutputRootFile"                                              << G4endl
	     << "        --- InputMacro     = mac/run_1e3.mac (example)"                                                  << G4endl
	     << "        --- OutputRootFile = hoge.root (example)"                                                        << G4endl
    //   << "        --- ParticleType   = [gamma, e-, e+, neutron, alpha]"                                            << G4endl
    //	   << "        --- ParticleEnergy = 1 (example)"                                                                << G4endl
    //	   << "        --- PositionType   = [all, rock, SUS304, H2O, LS, CaF2, point]"                                  << G4endl
	     << "----------------------------------------------------"                                                    << G4endl
	     << G4endl
	     << "MCType = 1: GPS MC controled by macro"                                                                   << G4endl
	     << " Usage: " << argv[0] << " InputMacro MCType OutputRootFile"                                              << G4endl
	     << "        --- InputMacro     = mac/GPS_Y88_W011_top.mac (example)"                                         << G4endl
	     << "        --- OutputRootFile = hoge.root (example)"                                                        << G4endl
	     << G4endl
    //   << "Geometry mode"                                                                                           << G4endl
    //	   << " Usage: " << argv[0] << " mac/vis_DAWNFILE.mac"                                                          << G4endl
    //	   << "        --- InputMacro     = mac/vis_DAWNFILE.mac (example)"                                             << G4endl
	     << "------------------------------------------------------------------------------------------------"        << G4endl                     
    
	     << G4endl;
      exit(8);
    }
   
   // G4String rootFileName;
   //  G4String particleType;
   //  G4double particleEnergy;
   //  G4String positionType;
   
 // if (argc == 3) {
 if (mcType == 0 || mcType == 1) { // Monochromatic beam mode 
    rootFileName = argv[3];
    /*   particleType   = argv[4];
       particleEnergy = atof(argv[5]);
       positionType   = argv[6];
     if (!(particleType == "gamma" || particleType == "e-" || particleType == "e+" || particleType == "neutron" || particleType == "alpha")) {
      G4cerr << "Error: particle type is wrong, " << particleType << "!" << G4endl;
      exit(8);
    }
    if (!(0 < particleEnergy && particleEnergy < 100)) {
      G4cerr << "Error: particle energy is wrong, " << particleEnergy << "!" << G4endl;
      exit(8);
    }
    if (!(positionType == "all" || positionType == "rock" || positionType == "SUS304" || positionType == "H2O" || positionType == "LS" || positionType == "CaF2" || positionType == "point")) {
      G4cerr << "Error: position type is wrong, " << positionType << "!" << G4endl;
      exit(8);
      }*/

    }
  // else if (mcType == 1) { // GPS mode
  //  rootFileName   = argv[3];
    //  particleType   = "NULL";
    //   particleEnergy = -1;
    //  positionType   = "NULL";
  // }
    /*    else if (mcType == -1) { // Geometry mode
    G4String macFile = argv[1];
    if (macFile != "mac/vis_DAWNFILE.mac") {
      G4cerr << "Error: mac file should be mac/vis_DAWNFILE.mac" << G4endl;
      exit(8);
  }
  }*/
    else {
      G4cerr << "Error: MC type should be 0 or 1 or 2!" << G4endl;
      exit(8);
    }
  }
  //---------------------------------------------------------------------------------//

  // change random seed
  // long seed = time(NULL);
  // G4Random::setTheSeed(seed);

  // vary random seed
#if 1
  long seed = time(NULL);
  CLHEP::HepRandom::setTheSeed(seed);
#endif
  // fix random seed
#if 0
  CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);
#endif

  // Construct the default run manager
  //
  G4RunManager* runManager = new G4RunManager;

  // Set mandatory initialization classes
  //
  CAN3DetectorConstruction* detector = new CAN3DetectorConstruction;
  runManager -> SetUserInitialization(detector);
  //
  // ref. Physics lists Use cases --- http://geant4.cern.ch/support/proc_mod_catalog/physics_lists/useCases.shtml
  G4VModularPhysicsList* physics = new Shielding; // Shielding applications, underground physics
  runManager -> SetUserInitialization(physics);

  // set an HistoManager
  //
  CAN3HistoManager* histo = new CAN3HistoManager(rootFileName);
      
  // Set user action classes
  //
   CAN3PrimaryGeneratorAction* gen_action = new CAN3PrimaryGeneratorAction(mcType);
  //  CAN3PrimaryGeneratorAction* gen_action = new CAN3PrimaryGeneratorAction(mcType, particleType, particleEnergy, positionType); 

  runManager -> SetUserAction(gen_action);
  //
  CAN3RunAction* run_action = new CAN3RunAction(histo);
  runManager -> SetUserAction(run_action);
  //
  CAN3EventAction* event_action = new CAN3EventAction(run_action, gen_action, histo);
  runManager -> SetUserAction(event_action);
  //
  G4UserSteppingAction* stepping_action = new CAN3SteppingAction(detector, event_action);
  runManager -> SetUserAction(stepping_action);
  
  // Initialize G4 kernel
  //
  runManager -> Initialize();

#ifdef G4VIS_USE
  // Initialize visualization
  //
  G4VisManager* visManager = new G4VisExecutive;
  visManager -> Initialize();
#endif

  // Get the pointer to the User Interface manager
  //
  G4UImanager* UImanager = G4UImanager::GetUIpointer();      

  if (argc != 1)   // batch mode
    {
      G4String command = "/control/execute ";
      G4String fileName = argv[1];
      UImanager -> ApplyCommand(command+fileName);
    }
  else
    {  // interactive mode : define UI session
#ifdef G4UI_USE
      G4UIExecutive* ui = new G4UIExecutive(argc, argv);
#ifdef G4VIS_USE
      UImanager -> ApplyCommand("/control/execute vis.mac"); 
#endif
      if (ui -> IsGUI())
        UImanager -> ApplyCommand("/control/execute gui.mac");
      ui -> SessionStart();
      delete ui;
#endif
    }

  // Job termination
  // Free the store: user actions, physics_list and detector_description are
  //                 owned and deleted by the run manager, so they should not
  //                 be deleted in the main() program !
#ifdef G4VIS_USE
  delete visManager;
#endif
  delete histo; // added
  delete runManager;

  return 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
