// 2014/10/29 K.Nakajima
//
#include "CAN3DetectorConstruction.hh"

#include "G4Material.hh"
#include "G4NistManager.hh"

#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Trd.hh"
#include "G4UnionSolid.hh"

#include "G4SDManager.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"
#include "G4SubtractionSolid.hh"

#include "G4SystemOfUnits.hh"

#include <iomanip>
using namespace std; // kyohei

//#define WITH_SHIELD 1
//#define WITH_PMT    1

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3DetectorConstruction::CAN3DetectorConstruction()
{
  //
  // define material
  //
  DefineMaterials();
  /*
  G4Material* WorldMaterial    = G4Material::GetMaterial("G4_Galactic");
  G4Material* VacuumMaterial   = G4Material::GetMaterial("G4_Galactic");
  G4Material* PbShieldMaterial = G4Material::GetMaterial("G4_Pb");
  G4Material* AirMaterial      = G4Material::GetMaterial("G4_AIR");
  G4Material* NaIMaterial      = G4Material::GetMaterial("G4_SODIUM_IODIDE");
  G4Material* NaMaterial       = G4Material::GetMaterial("G4_SODIUM_IODIDE");
  G4Material* LSMaterial       = G4Material::GetMaterial("LS");
  G4Material* PMTMaterial      = G4Material::GetMaterial("Glass");
  G4Material* AcrylBoxMaterial = G4Material::GetMaterial("Acryl");
  G4Material* WLSMaterial      = G4Material::GetMaterial("MineralOil");
  G4Material* CaF2Material     = G4Material::GetMaterial("G4_CALCIUM_FLUORIDE");
  G4Material* CrystalMaterial  = G4Material::GetMaterial("CaF2"); 
  G4Material* WaterMaterial      = G4Material::GetMaterial("G4_WATER");
  G4Material* RockMaterial       = G4Material::GetMaterial("Rock");
  G4Material* SUSMaterial        = G4Material::GetMaterial("Stainless");
  G4Material* LSTankMaterial     = G4Material::GetMaterial("Acryl");
  */
  WorldMaterial    = G4Material::GetMaterial("G4_Galactic");
  VacuumMaterial   = G4Material::GetMaterial("G4_Galactic");
  PbShieldMaterial = G4Material::GetMaterial("G4_Pb");
  AirMaterial  = G4Material::GetMaterial("G4_AIR");
  NaIMaterial  = G4Material::GetMaterial("G4_SODIUM_IODIDE");
  NaMaterial   = G4Material::GetMaterial("G4_SODIUM_IODIDE");
  LSMaterial   = G4Material::GetMaterial("LS");
  PMTMaterial  = G4Material::GetMaterial("Glass");
  AcrylBoxMaterial = G4Material::GetMaterial("Acryl");
  WLSMaterial  = G4Material::GetMaterial("MineralOil");
  CaF2Material     = G4Material::GetMaterial("G4_CALCIUM_FLUORIDE");
  CrystalMaterial  = G4Material::GetMaterial("CaF2"); 
  WaterMaterial  = G4Material::GetMaterial("G4_WATER");
  RockMaterial   = G4Material::GetMaterial("Rock");
  SUSMaterial    = G4Material::GetMaterial("Stainless");
  LSTankMaterial     = G4Material::GetMaterial("Acryl");

/*
#if WITH_SHIELD
  G4Material* PbMaterial         = G4Material::GetMaterial("G4_Pb");
  G4Material* BShieldMaterial    = G4Material::GetMaterial("RubberB4C");
  G4Material* NGenMaterial       = G4Material::GetMaterial("G4_Galactic");  
#endif
*/

  /*
  fWorldMaterial    = G4Material::GetMaterial("G4_Galactic");
  fVacuumMaterial   = G4Material::GetMaterial("G4_Galactic");
  fPbShieldMaterial = G4Material::GetMaterial("G4_Pb");
  fAirMaterial      = G4Material::GetMaterial("G4_AIR");
  fNaIMaterial      = G4Material::GetMaterial("G4_SODIUM_IODIDE");
  fNaMaterial       = G4Material::GetMaterial("G4_SODIUM_IODIDE");
  fLSMaterial       = G4Material::GetMaterial("LS");
  fPMTMaterial      = G4Material::GetMaterial("Glass");
  fAcrylBoxMaterial = G4Material::GetMaterial("Acryl");
  fWLSMaterial      = G4Material::GetMaterial("MineralOil");
  fCaF2Material     = G4Material::GetMaterial("G4_CALCIUM_FLUORIDE");
  fCrystalMaterial  = G4Material::GetMaterial("CaF2"); 
  */
  //fLSTankMaterial     = G4Material::GetMaterial("Acryl");

  /*
  G4Material* vacuumMaterial     = G4Material::GetMaterial("G4_Galactic");
  G4Material* rockMaterial       = G4Material::GetMaterial("Rock");
  G4Material* SUSMaterial        = G4Material::GetMaterial("Stainless");
  G4Material* waterMaterial      = G4Material::GetMaterial("G4_WATER");
  G4Material* airMaterial        = G4Material::GetMaterial("G4_AIR");
  G4Material* PMTMaterial        = G4Material::GetMaterial("Glass");
  G4Material* acrylBoxMaterial   = G4Material::GetMaterial("Acryl");
  G4Material* LSTankMaterial     = G4Material::GetMaterial("Acryl");
  G4Material* LSMaterial         = G4Material::GetMaterial("LS");
  G4Material* WLSMaterial        = G4Material::GetMaterial("MineralOil");
  G4Material* CaF2Material       = G4Material::GetMaterial("G4_CALCIUM_FLUORIDE");
#if WITH_SHIELD
  G4Material* PbMaterial         = G4Material::GetMaterial("G4_Pb");
  G4Material* BShieldMaterial    = G4Material::GetMaterial("RubberB4C");
  G4Material* NGenMaterial       = G4Material::GetMaterial("G4_Galactic");  
#endif
  */

  // colour
  white   = G4Colour(1.0,  1.0,  1.0);
  grey    = G4Colour(0.5,  0.5,  0.5);
  red     = G4Colour(1.0,  0.0,  0.0);
  green   = G4Colour(0.0,  1.0,  0.0);
  blue    = G4Colour(0.0,  0.0,  1.0);
  //G4Colour  black   (0.0, 0.0, 0.0) ;  // black
  //G4Colour  cyan    (0.0, 1.0, 1.0) ;  // cyan
  //G4Colour  yellow  (1.0, 1.0, 0.0) ;  // yellow
  //G4Colour magenta = G4Colour(1.0,  0.0,  1.0); 
  //G4Colour brown   = G4Colour(0.7,  0.4,  0.1);
  magenta = G4Colour(1.0,  0.0,  1.0); 
  brown   = G4Colour(0.7,  0.4,  0.1);
  black   = G4Colour(0.0, 0.0, 0.0) ;  // black
  cyan    = G4Colour(0.0, 1.0, 1.0) ;  // cyan
  yellow  = G4Colour(1.0, 1.0, 0.0) ;  // yellow

  //G4Colour  red     (1.0, 0.0, 0.0) ;  // red
  //G4Colour  green   (0.0, 1.0, 0.0) ;  // green
  //G4Colour  blue    (0.0, 0.0, 1.0) ;  // blue
  //G4Colour  magenta (1.0, 0.0, 1.0) ;  // magenta 
  //  G4Colour black   = G4Colour(0.0,  0.0,  0.0);
  //  G4Colour lgrey   = G4Colour(0.85, 0.85, 0.85);
  //  G4Colour orange  = G4Colour(0.75, 0.55, 0.0);
  //  G4Colour yellow  = G4Colour(1.0,  1.0,  0.0);
  //  G4Colour lgreen  = G4Colour(0.0,  0.75, 0.0);
  //  G4Colour lblue   = G4Colour(0.0,  0.0,  0.75);
  //  G4Colour cyan    = G4Colour(0.0,  1.0,  1.0);
  //  G4Colour purple  = G4Colour(0.85, 0.44, 0.84);
  //G4Colour  white   ()              ;  // white
  //G4Colour  white   (1.0, 1.0, 1.0) ;  // white
  //G4Colour  gray    (0.5, 0.5, 0.5) ;  // gray

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3DetectorConstruction::~CAN3DetectorConstruction()
{;}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* CAN3DetectorConstruction::Construct()
{
  //
  // visibility flag
  //
  G4bool visFlagWorld      = 1; // white
  G4bool visFlagRock       = 1; // brown
  G4bool visFlagBufferTank = 1; // red
  G4bool visFlagBuffer     = 1; // blue
  G4bool visFlagAir        = 1; // blue
  G4bool visFlagPMT1       = 1; // blue
  G4bool visFlagPMT2       = 1; // blue
  G4bool visFlagPMTVoid    = 1; // red
  G4bool visFlagLSTank     = 1; // white
  G4bool visFlagLS         = 1; // green
  G4bool visFlagAcrylBox   = 1; // white
  G4bool visFlagAcrylOut   = 1; // white
  G4bool visFlagAcrylIn    = 1; // white
  G4bool visFlagWLS        = 1; // green
  G4bool visFlagCaF2       = 1; // magenta
  G4bool visFlagPbShield   = 1; // grey
  G4bool visFlagBShield    = 1; // green
  G4bool visFlagNGen       = 1; // magenta
  G4bool visFlagNaI1       = 1; // red
  G4bool visFlagNaI2       = 1; // green

  /*
#if WITH_SHIELD
  G4bool visFlagPbShield   = 1; // grey
  G4bool visFlagBShield    = 1; // green
  G4bool visFlagNGen       = 1; // magenta
#endif
 */

  //
  // copy number
  //
  G4int copyNoWorld          = 9;
  G4int copyNoPbShield       = 8;
  G4int copyNoAir            = 7;
  G4int copyNoNaI1   	     = 1;
  G4int copyNoNaI2           = 6;
  G4int copyNoRock           = 1100;
  G4int copyNoBufferTank     = 1001;
  G4int copyNoBuffer         = 1002;
  G4int copyNoLSTank         = 1003;
  G4int copyNoLS             = 1004;
  G4int copyNoAcrylBox       =5;
  G4int copyNoAcrylOut       =13;
  G4int copyNoAcrylIn        =12;
  G4int copyNoWLS            =11;
  G4int copyNoCaF2           =4;
  G4int copyNoPMT1           =2;
  G4int copyNoPMT2           =3;

  //
  // Geometry parameters
  //
  // thickness here means side thickness from inside layer
  // geometry is cube box for all except NaI detector, source and PMTs
  // CaF2 Crystal Box Size
  const G4double CaF2BoxSizeZ        = 10 *cm;
  const G4double CaF2BoxSizeX        = 10 *cm;
  const G4double CaF2BoxSizeY        = 10 *cm;

  // WLS Box Size
  const G4double WLSBoxThickness     = 5  *mm;
  const G4double WLSBoxSizeZ         = CaF2BoxSizeZ + 2*WLSBoxThickness;
  const G4double WLSBoxSizeX         = CaF2BoxSizeX + 2*WLSBoxThickness;
  const G4double WLSBoxSizeY         = CaF2BoxSizeY + 2*WLSBoxThickness;

  // AcrylBox Size (Inside) for holding crystal and WLS
  const G4double AcrylInBoxThickness   = 2.5 *mm;
  const G4double AcrylInBoxSizeZ       = WLSBoxSizeZ + 2*AcrylInBoxThickness;
  const G4double AcrylInBoxSizeX       = WLSBoxSizeX + 2*AcrylInBoxThickness;
  const G4double AcrylInBoxSizeY       = WLSBoxSizeY + 2*AcrylInBoxThickness;

  // LSBox Size
  const G4double LSBoxThickness      = 5  *cm;
  const G4double LSBoxSizeZ          = AcrylInBoxSizeZ + 2*LSBoxThickness;
  const G4double LSBoxSizeX          = AcrylInBoxSizeX + 2*LSBoxThickness;
  const G4double LSBoxSizeY          = AcrylInBoxSizeY + 2*LSBoxThickness;

  // AcrylBox Size (Outside) for holding LS and crystal components
  const G4double AcrylOutBoxThickness   = 2.5  *mm;
  const G4double AcrylOutBoxSizeZ       = LSBoxSizeZ + 2*AcrylOutBoxThickness;
  const G4double AcrylOutBoxSizeX       = LSBoxSizeX + 2*AcrylOutBoxThickness;
  const G4double AcrylOutBoxSizeY       = LSBoxSizeY + 2*AcrylOutBoxThickness;
  
  // Pb shield
  const G4double PbShieldBoxThickness   = 5  *cm;
  const G4double PbShieldBoxSizeZ       = AcrylOutBoxSizeZ + 2*PbShieldBoxThickness;
  const G4double PbShieldBoxSizeX       = AcrylOutBoxSizeX + 2*PbShieldBoxThickness;
  const G4double PbShieldBoxSizeY       = AcrylOutBoxSizeY + 2*PbShieldBoxThickness;

  // World
  const G4double WorldBoxThickness   = 10  *cm;
  const G4double WorldBoxSizeZ       = PbShieldBoxSizeZ + 2*WorldBoxThickness;
  const G4double WorldBoxSizeX       = PbShieldBoxSizeX + 2*WorldBoxThickness;
  const G4double WorldBoxSizeY       = PbShieldBoxSizeY + 2*WorldBoxThickness;

  // NaI 2 as source, cylinder 2x6 inch
  const G4double NaDiameter       = 2.5 *cm;
  const G4double NaHeight         = 4   *cm;//15.24 *cm;
  const G4double NaI1Diameter       = 1.6 *cm;
  const G4double NaI1Height         = 7   *cm;//15.24 *cm;
  const G4double NaI2Diameter       = 1.6 *cm;
  const G4double NaI2Height         = 5   *cm;//15.24 *cm;

  // PMT, cylinder 3x7 inch
  const G4double PMT1Diameter       = 1.5 *cm;
  const G4double PMT1Height         = 11.5 *cm;//15.24 *cm;
  const G4double PMT2Diameter       = 1.5 *cm;
  const G4double PMT2Height         = 9.5 *cm;//15.24 *cm;

  /////////////////////////////
  // Position placement parameters
  /////////////////////////////
  // position of NaI
  //const G4double NaIPosZ       = 5.5 *cm;    //length
  //const G4double NaIPosX       = -4.075 *cm; //width
  //const G4double NaIPosY       = -1.825 *cm; //height
  //const G4double NaIPosZ       = (0.3 + NaHeight/2) *cm; //height
  //const G4double NaIPosX       = 0 *cm; //width
  //const G4double NaIPosY       = -(LSBoxThickness/2 + AcrylInBoxSizeY/2) *cm;    //length
  const G4double NaI1PosZ       = 2.3 *cm; //height, put 0.2mm so that 
  const G4double NaI1PosX       = -9.8 *cm; //width
  const G4double NaI1PosY       = 0 *cm;    //length

  const G4double NaI2PosZ       = 2.3 *cm; //height, put 0.2mm so that 
  const G4double NaI2PosX       = +9.8 *cm; //width
  const G4double NaI2PosY       = 0 *cm;    //length

  //PMT position
  //const G4double PMTPosZ       = (0.3 + NaHeight + PMTHeight/2 + 0.02) *cm; //height, put 0.2mm so that dont touch/overlap with NaI end
  //const G4double PMTPosZ       = (0.3 + NaHeight + PMTHeight/2 + 0.02) *cm; //height, put 0.2mm so that 
  //const G4double PMTPosX       = 0 *cm; //width
  //const G4double PMTPosY       = -(LSBoxThickness/2 + AcrylInBoxSizeY/2) *cm;    //length
  const G4double PMT1PosZ       = (7.8 + 0.1) *cm; //height, put 0.2mm so that 
  const G4double PMT1PosX       = -9.8 *cm; //width
  const G4double PMT1PosY       = 0 *cm;    //length
  const G4double PMT2PosZ       = (7.8 + 0.1) *cm; //height, put 0.2mm so that 
  const G4double PMT2PosX       = +9.8 *cm; //width
  const G4double PMT2PosY       = 0 *cm;    //length

  //position of NaI 2 as source
  //const G4double NaPosZ       =  5.5  *cm; //7.65 *cm; //5.5 *cm;    //length
  //const G4double NaPosX       =  2.425 *cm; //2.05 *cm; //width
  //const G4double NaPosY       = -1.825 *cm;//-2.45 *cm; //height

  /*  // geometory parameter values
  // World	 			  
  const G4double worldBoxSizeX     = 100 *cm;
  const G4double worldBoxSizeY     = 70 *cm;
  const G4double worldBoxSizeZ     = 70 *cm;
  // PbShield
  const G4double PbShieldBoxSizeX  = 55 *cm;
  const G4double PbShieldBoxSizeY  = 26.5 *cm;
  const G4double PbShieldBoxSizeZ  = 26.5 *cm;
  // Air
  const G4double AirBoxSizeX       = 45 *cm;
  const G4double AirBoxSizeY       = 16.5 *cm;
  const G4double AirBoxSizeZ       = 16.5 *cm;
  
  // NaI
  const G4double NaIBoxSizeX       = 34.48 *cm;
  const G4double NaIBoxSizeY       = 6.5 *cm;
  const G4double NaIBoxSizeZ       = 6.5 *cm;

  //position of NaI
  const G4double NaIPosX       = 0 *cm;
  const G4double NaIPosY       = 0 *cm;
  const G4double NaIPosZ       = 0 *cm;*/
  //
  // Construct
  //

  // World ////////////////////
/*  G4Box*             WorldSolid    = new G4Box("World", WorldBoxSizeX / 2.0, WorldBoxSizeY / 2.0, WorldBoxSizeZ / 2.0);
  G4LogicalVolume*   WorldLogical  = new G4LogicalVolume(WorldSolid, WorldMaterial, "World");
  G4VPhysicalVolume* WorldPhysical = new G4PVPlacement(0, G4ThreeVector(), WorldLogical, "World", 0, false, copyNoWorld);

  G4VisAttributes* worldVisAtt = new G4VisAttributes(white);
  worldVisAtt  -> SetVisibility(visFlagWorld);
  worldLogical -> SetVisAttributes(worldVisAtt);*/

  /*  // geometory parameter values
  // World	 			  
  const G4double worldBoxSizeX     = 100 *cm;
  const G4double worldBoxSizeY     = 70 *cm;
  const G4double worldBoxSizeZ     = 70 *cm;
  // PbShield
  const G4double PbShieldBoxSizeX  = 55 *cm;
  const G4double PbShieldBoxSizeY  = 26.5 *cm;
  const G4double PbShieldBoxSizeZ  = 26.5 *cm;
  // Air
  const G4double AirBoxSizeX       = 45 *cm;
  const G4double AirBoxSizeY       = 16.5 *cm;
  const G4double AirBoxSizeZ       = 16.5 *cm;
  
  // NaI
  const G4double NaIBoxSizeX       = 34.48 *cm;
  const G4double NaIBoxSizeY       = 6.5 *cm;
  const G4double NaIBoxSizeZ       = 6.5 *cm;

  //position of NaI
  const G4double NaIPosX       = 0 *cm;
  const G4double NaIPosY       = 0 *cm;
  const G4double NaIPosZ       = 0 *cm;*/

  //
  // Construct
  //
  // World ////////////////////
  // Mother = None
  G4Box*             WorldSolid    = new G4Box("World", WorldBoxSizeX / 2.0, WorldBoxSizeY / 2.0, WorldBoxSizeZ / 2.0);
  G4LogicalVolume*   WorldLogical  = new G4LogicalVolume(WorldSolid, WorldMaterial, "World");
  G4VPhysicalVolume* WorldPhysical = new G4PVPlacement(0, G4ThreeVector(), WorldLogical, "World", 0, false, copyNoWorld);

  G4VisAttributes* WorldVisAtt = new G4VisAttributes(black);
  WorldVisAtt  -> SetVisibility(visFlagWorld);
  WorldLogical -> SetVisAttributes(WorldVisAtt);

  // PbShield /////////////
  // Mother = World
  G4Box*             PbShieldSolid   = new G4Box("PbShield", PbShieldBoxSizeX / 2.0, PbShieldBoxSizeY / 2.0, PbShieldBoxSizeZ / 2.0);
  G4LogicalVolume*   PbShieldLogical = new G4LogicalVolume(PbShieldSolid, PbShieldMaterial, "PbShield");
  new G4PVPlacement(0, G4ThreeVector(), PbShieldLogical, "PbShield", WorldLogical, false, copyNoPbShield);

  G4VisAttributes* PbShieldVisAtt = new G4VisAttributes(grey);
  PbShieldVisAtt  -> SetVisibility(visFlagPbShield);
  PbShieldLogical -> SetVisAttributes(PbShieldVisAtt);

/*  // Air /////////////
  // Mother = PbShield
  G4Box*             AirSolid    = new G4Box("Air", AirBoxSizeX / 2.0, AirBoxSizeY / 2.0, AirBoxSizeZ / 2.0);
  G4LogicalVolume*   AirLogical  = new G4LogicalVolume(AirSolid, fAirMaterial, "Air");
  new G4PVPlacement(0, G4ThreeVector(), AirLogical, "Air", PbShieldLogical, false, copyNoAir);

  G4VisAttributes* AirVisAtt = new G4VisAttributes(blue);
  AirVisAtt  -> SetVisibility(visFlagAir);
  AirLogical -> SetVisAttributes(AirVisAtt);*/

  // AcrylBox (Out) /////////////
  // Mother = PbShield
  G4Box*             AcrylOutSolid    = new G4Box("AcrylOut", AcrylOutBoxSizeX / 2.0, AcrylOutBoxSizeY / 2.0, AcrylOutBoxSizeZ / 2.0);
  G4LogicalVolume*   AcrylOutLogical  = new G4LogicalVolume(AcrylOutSolid, AcrylBoxMaterial, "AcrylOut");
  new G4PVPlacement(0, G4ThreeVector(), AcrylOutLogical, "AcrylOut", PbShieldLogical, false, copyNoAcrylOut);

  G4VisAttributes* AcrylOutVisAtt = new G4VisAttributes(brown);
  AcrylOutVisAtt  -> SetVisibility(visFlagAcrylOut);
  AcrylOutLogical -> SetVisAttributes(AcrylOutVisAtt);

  // LS /////////////
  // Mother = AcrylOut
  G4Box* LSSolid    = new G4Box("LS", LSBoxSizeX / 2.0, LSBoxSizeY / 2.0, LSBoxSizeZ / 2.0);
  G4LogicalVolume*   LSLogical  = new G4LogicalVolume(LSSolid, LSMaterial, "LS");
  new G4PVPlacement(0, G4ThreeVector(), LSLogical, "LS", AcrylOutLogical, false, copyNoLS);

  G4VisAttributes* LSVisAtt = new G4VisAttributes(blue);
  LSVisAtt  -> SetVisibility(visFlagLS);
  LSLogical -> SetVisAttributes(LSVisAtt);

  // AcrylBox (In) /////////////
  // Mother = LS
  G4Box*             AcrylInSolid    = new G4Box("AcrylIn", AcrylInBoxSizeX / 2.0, AcrylInBoxSizeY / 2.0, AcrylInBoxSizeZ / 2.0);
  G4LogicalVolume*   AcrylInLogical  = new G4LogicalVolume(AcrylInSolid, AcrylBoxMaterial, "AcrylIn");
  new G4PVPlacement(0, G4ThreeVector(), AcrylInLogical, "AcrylIn", LSLogical, false, copyNoAcrylIn);

  G4VisAttributes* AcrylInVisAtt = new G4VisAttributes(brown);
  AcrylInVisAtt  -> SetVisibility(visFlagAcrylIn);
  AcrylInLogical -> SetVisAttributes(AcrylInVisAtt);

  // WLS /////////////
  // Mother = AcrylIn
  G4Box* WLSSolid    = new G4Box("WLS", WLSBoxSizeX / 2.0, WLSBoxSizeY / 2.0, WLSBoxSizeZ / 2.0);
  G4LogicalVolume*   WLSLogical  = new G4LogicalVolume(WLSSolid, WLSMaterial, "WLS");
  new G4PVPlacement(0, G4ThreeVector(), WLSLogical, "WLS", AcrylInLogical, false, copyNoWLS);

  G4VisAttributes* WLSVisAtt = new G4VisAttributes(cyan);
  WLSVisAtt  -> SetVisibility(visFlagWLS);
  WLSLogical -> SetVisAttributes(WLSVisAtt);

  // CaF2 /////////////
  // Mother = WLS
  G4Box* CaF2Solid    = new G4Box("CaF2", CaF2BoxSizeX / 2.0, CaF2BoxSizeY / 2.0, CaF2BoxSizeZ / 2.0);
  G4LogicalVolume*   CaF2Logical  = new G4LogicalVolume(CaF2Solid, CaF2Material, "CaF2");
  new G4PVPlacement(0, G4ThreeVector(), CaF2Logical, "CaF2", WLSLogical, false, copyNoCaF2);

  G4VisAttributes* CaF2VisAtt = new G4VisAttributes(magenta);
  CaF2VisAtt  -> SetVisibility(visFlagCaF2);
  CaF2Logical -> SetVisAttributes(CaF2VisAtt);

  // PMT (for source, beta)  /////////////
  // Mother = LS
    G4Tubs*            PMT1Solid    = new G4Tubs("PMT1", 0, PMT1Diameter / 2.0, PMT1Height / 2.0, 0.0 *deg, 360.0 *deg);
    //G4Tubs*            PMTSolid    = new G4Tubs("PMT", 90*deg, PMTDiameter / 2.0, PMTHeight / 2.0, 0.0 *deg, 360.0 *deg); //rotated
  //G4Box*            NaSolid    = new G4Box("NaI", NaIBoxSizeX / 2.0, NaIBoxSizeY / 2.0, NaIBoxSizeZ / 2.0 );
  G4LogicalVolume*   PMT1Logical  = new G4LogicalVolume(PMT1Solid, PMTMaterial, "PMT1");
  new G4PVPlacement(0, G4ThreeVector(PMT1PosX, PMT1PosY, PMT1PosZ),  PMT1Logical, "PMT1", LSLogical, false, copyNoPMT1);   //careful, daughter always placed at center of its mother and then shifted as implied, also careful cylinder always created to extend in z position

  G4VisAttributes* PMT1VisAtt = new G4VisAttributes(green);
  PMT1VisAtt  -> SetVisibility(visFlagPMT1);
  PMT1Logical -> SetVisAttributes(PMT1VisAtt);

  // NaI source,beta  /////////////
  // Mother = LS
    G4Tubs*            NaI1Solid    = new G4Tubs("NaI1", 0, NaI1Diameter / 2.0, NaI1Height / 2.0, 0.0 *deg, 360.0 *deg);
    //G4Tubs*            NaISolid    = new G4Tubs("NaI", 90*deg, NaIDiameter / 2.0, NaIHeight / 2.0, 0.0 *deg, 360.0 *deg); //rotated 90deg
  //G4Box*            NaSolid    = new G4Box("NaI", NaIBoxSizeX / 2.0, NaIBoxSizeY / 2.0, NaIBoxSizeZ / 2.0 );
  G4LogicalVolume*   NaI1Logical  = new G4LogicalVolume(NaI1Solid, NaIMaterial, "NaI1");
  new G4PVPlacement(0, G4ThreeVector(NaI1PosX, NaI1PosY, NaI1PosZ),  NaI1Logical, "NaI1", LSLogical, false, copyNoNaI1);   //careful, daughter always placed at center of its mother and then shifted as implied, also careful cylinder always created to extend in z position

  G4VisAttributes* NaI1VisAtt = new G4VisAttributes(red);
  NaI1VisAtt  -> SetVisibility(visFlagNaI1);
  NaI1Logical -> SetVisAttributes(NaI1VisAtt);

  // PMT (for detector, gamma)  /////////////
  // Mother = LS
  G4Tubs*            PMT2Solid    = new G4Tubs("PMT2", 0, PMT2Diameter / 2.0, PMT2Height / 2.0, 0.0 *deg, 360.0 *deg);
  G4LogicalVolume*   PMT2Logical  = new G4LogicalVolume(PMT2Solid, PMTMaterial, "PMT2");
  new G4PVPlacement(0, G4ThreeVector(PMT2PosX, PMT2PosY, PMT2PosZ),  PMT2Logical, "PMT2", LSLogical, false, copyNoPMT2);   

  G4VisAttributes* PMT2VisAtt = new G4VisAttributes(green);
  PMT2VisAtt  -> SetVisibility(visFlagPMT2);
  PMT2Logical -> SetVisAttributes(PMT2VisAtt);

  // NaI detector,gamma  /////////////
  // Mother = LS
  G4Tubs*            NaI2Solid    = new G4Tubs("NaI2", 0, NaI2Diameter / 2.0, NaI2Height / 2.0, 0.0 *deg, 360.0 *deg);
  G4LogicalVolume*   NaI2Logical  = new G4LogicalVolume(NaI2Solid, NaIMaterial, "NaI2");
  new G4PVPlacement(0, G4ThreeVector(NaI2PosX, NaI2PosY, NaI2PosZ),  NaI2Logical, "NaI2", LSLogical, false, copyNoNaI2);   

  G4VisAttributes* NaI2VisAtt = new G4VisAttributes(red);
  NaI2VisAtt  -> SetVisibility(visFlagNaI2);
  NaI2Logical -> SetVisAttributes(NaI2VisAtt);

/*
  // NaI detector  /////////////
  // Mother = Air
  G4Box*            NaISolid    = new G4Box("NaI", NaIBoxSizeX / 2.0, NaIBoxSizeY / 2.0, NaIBoxSizeZ / 2.0 );
  G4LogicalVolume*   NaILogical  = new G4LogicalVolume(NaISolid, fNaIMaterial, "NaI");
  new G4PVPlacement(0, G4ThreeVector(NaIPosX, NaIPosY, NaIPosZ),  NaILogical, "NaI", AirLogical, false, copyNoNaI);

  G4VisAttributes* NaIVisAtt = new G4VisAttributes(red);
  NaIVisAtt  -> SetVisibility(visFlagNaI);
  NaILogical -> SetVisAttributes(NaIVisAtt);
*/
/*  
 // NaI source  /////////////
  // Mother = Air
  //  G4Tubs*            NaSolid    = new G4Tubs("Na", 0, NaDiameter / 2.0, NaHeight / 2.0, 0.0 *deg, 360.0 *deg);
  G4Box*            NaSolid    = new G4Box("NaI", NaIBoxSizeX / 2.0, NaIBoxSizeY / 2.0, NaIBoxSizeZ / 2.0 );
  G4LogicalVolume*   NaLogical  = new G4LogicalVolume(NaSolid, fNaMaterial, "Na");
  new G4PVPlacement(0, G4ThreeVector(NaPosX, NaPosY, NaPosZ),  NaLogical, "Na", AirLogical, false, copyNoNa);

  G4VisAttributes* NaVisAtt = new G4VisAttributes(green);
  NaVisAtt  -> SetVisibility(visFlagNa);
  NaLogical -> SetVisAttributes(NaVisAtt);
*/  

  // always return the physical world
  return WorldPhysical;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3DetectorConstruction::DefineMaterials()
{
  // Material definitions and compositions are from CANDLES3 simulation
  // Added NaI composition for NaI scintillating crystal

  // Material defined using NIST Manager
  // http://geant4.web.cern.ch/geant4/G4UsersDocuments/UsersGuides/ForApplicationDeveloper/html/Detector/materialNames.html
  G4NistManager* nistManager = G4NistManager::Instance();
  nistManager -> FindOrBuildMaterial("G4_Galactic");
  nistManager -> FindOrBuildMaterial("G4_Pb");
  nistManager -> FindOrBuildMaterial("G4_AIR");
  nistManager -> FindOrBuildMaterial("G4_SODIUM_IODIDE");
  nistManager -> FindOrBuildMaterial("G4_CALCIUM_FLUORIDE");
  nistManager -> FindOrBuildMaterial("G4_WATER");

  G4double a; // atomic mass
  G4double z; // atomic number (number of protons)
  G4double fractionmass, density;
  G4int    ncomponents, natoms;
  G4String name, symbol;

  // define elements 
  G4Element* H  = nistManager -> FindOrBuildElement("H");
  G4Element* B  = nistManager -> FindOrBuildElement("B"); 
  G4Element* C  = nistManager -> FindOrBuildElement("C");
  G4Element* N  = nistManager -> FindOrBuildElement("N");
  G4Element* O  = nistManager -> FindOrBuildElement("O");
  G4Element* Ca = nistManager -> FindOrBuildElement("Ca");
  G4Element* Cr = nistManager -> FindOrBuildElement("Cr");
  G4Element* Fe = nistManager -> FindOrBuildElement("Fe");
  G4Element* Ni = nistManager -> FindOrBuildElement("Ni");
  // for rock
  G4Element* Na = nistManager -> FindOrBuildElement("Na");
  G4Element* Mg = nistManager -> FindOrBuildElement("Mg");
  G4Element* Al = nistManager -> FindOrBuildElement("Al"); 
  G4Element* Si = nistManager -> FindOrBuildElement("Si");
  G4Element* P  = nistManager -> FindOrBuildElement("P");
  G4Element* S  = nistManager -> FindOrBuildElement("S");
  G4Element* K  = nistManager -> FindOrBuildElement("K");
  G4Element* Ti = nistManager -> FindOrBuildElement("Ti");
  G4Element* Mn = nistManager -> FindOrBuildElement("Mn");

  ////////// Define  Materials from elemsnts
  // http://ie.lbl.gov/elem/elem.htm  and ...
  // http://www.matweb.com/membership/benefits.asp


  // CaF2 pure crystal ////////
  //

  G4Element* F  = new G4Element(name = "Fluorine",  symbol =  "F", z =  9.0, a = 18.9984032  *g/mole);
  //G4Element* Ca = new G4Element(name = "Calcium",   symbol = "Ca", z = 20.0, a = 40.078      *g/mole);
  //cannot overlap definition, leads to error

  G4Material* CaF2 = new G4Material("CaF2", density = 3.18 *g/cm3, ncomponents = 2);
  CaF2 -> AddElement(Ca, natoms = 1);
  CaF2 -> AddElement(F,  natoms = 2);
 
  // Water //////////////////
  //
  G4Material* H2O = new G4Material("Water", density = 1.0 * g/cm3, ncomponents = 2);
  H2O -> AddElement(H, natoms = 2);
  H2O -> AddElement(O, natoms = 1);

  // Materials for Lquid Scintillator and WLS //////////////////
  //
  // Mineral Oil (Paraol 250) C20H42 (Eicosane)
  density = 0.798 * g/cm3; // at 15 degree (http://www.showa-shell.co.jp/products/lub/product/Paraol130.pdf)
  G4Material* MineralOil = new G4Material("MineralOil", density, ncomponents = 2); // updated on 2013/07/01
  MineralOil -> AddElement(C, natoms = 20);
  MineralOil -> AddElement(H, natoms = 42);

  // Pseudocumene (CH3)3C6H3 = C9H12 (density = 0.872-0.877) 
  density = 0.8758 *g/cm3;  // at 20 deg.C (from MSDS, http://www.rcnp.osaka-u.ac.jp/~umehara/CANDLES/canwiki/index.php?plugin=attach&refer=CANWiki%2FCANInfo%2FCANIIIUG%2FLSPurificationSystem&openfile=PC.pdf)
  G4Material* Pseudocumene = new G4Material("Pseudocumene", density, ncomponents = 2);
  Pseudocumene -> AddElement(C, natoms = 9);
  Pseudocumene -> AddElement(H, natoms = 12);

  // bis-MSB (1.4-Bis(2-methylstynyl)benzene) = C24H22 !!! temporary density !!!
  density = 1.3*g/cm3; // No data in MSDS, written in GLG4DetectorConstruction.cc
  G4Material* BisMSB = new G4Material("Bis-MSB", density, ncomponents = 2);
  BisMSB -> AddElement(C, natoms = 24);
  BisMSB -> AddElement(H, natoms = 22);

  // DPO(PPO) (2.5-Diphenylozazole) C15H11NO !!! temporary density !!!
  density = 1.06 *g/cm3;  // No data in MSDS, written in GLG4DetectorConstruction.cc
  G4Material* PPO = new G4Material("PPO", density, ncomponents = 4);
  PPO -> AddElement(C, natoms = 15);
  PPO -> AddElement(H, natoms = 11);
  PPO -> AddElement(N, natoms = 1);
  PPO -> AddElement(O, natoms = 1);

  // Liquid Scintillator
  //--- Density data was measured by S.Yoshida. ---//
  // 0.81391 +/- 0.00001 g/cm3 at 15.03 deg.C
  // 0.81124 +/- 0.00001 g/cm3 at 17.53 deg.C
  // 0.80946 +/- 0.00001 g/cm3 at 20.02 deg.C
  //-----------------------------------------------//
  density = 0.80946 *g/cm3; // at 20.02 deg.C
  G4Material* LS = new G4Material("LS", density, ncomponents = 4);
  LS -> AddMaterial(MineralOil,   fractionmass = 78.37 *perCent); // 80 % volume ratio
  LS -> AddMaterial(Pseudocumene, fractionmass = 21.50 *perCent); // 20 % volume ratio
  LS -> AddMaterial(PPO,          fractionmass =  0.12 *perCent); // 1.0 g/l
  LS -> AddMaterial(BisMSB,       fractionmass =  0.01 *perCent); // 0.1 g/l

  // other materials
  //
  // Acryl //////////////////
  density = 1.19* g/cm3; // confirmed by web site
  G4Material* Acryl = new G4Material("Acryl", density, ncomponents = 3);
  Acryl -> AddElement(C, natoms =  9); // Not checked, not exact value!
  Acryl -> AddElement(H, natoms = 14); // Not checked, not exact value!
  Acryl -> AddElement(O, natoms =  4); // Not checked, not exact value!

  // Stainless SUS304 ///////////////
  density = 7.93 *g/cm3; // ref. http://www.yamco-yamashin.com/products/guide_specific_gravity.html
  G4Material* Stainless = new G4Material("Stainless", density, ncomponents = 3);
  Stainless -> AddElement(Fe, fractionmass = 71.7 *perCent);
  Stainless -> AddElement(Cr, fractionmass = 19.0 *perCent);
  Stainless -> AddElement(Ni, fractionmass =  9.3 *perCent); 

  // Rock //////////////////////
  // Silicon dioxide
  G4Material* SiO2  = new G4Material("SiO2",  density = 2.20 *g/cm3,   ncomponents = 2);
  SiO2 -> AddElement(Si, natoms = 1);
  SiO2 -> AddElement(O,  natoms = 2);  

  // Aluminium oxide
  G4Material* Al2O3 = new G4Material("Al2O3", density = 3.95 *g/cm3,   ncomponents = 2);
  Al2O3 -> AddElement(Al, natoms = 2);
  Al2O3 -> AddElement(O,  natoms = 3); 

  // Sodium oxide
  G4Material* Na2O  = new G4Material("Na2O",  density = 2.27 *g/cm3,  ncomponents = 2);
  Na2O -> AddElement(Na, natoms = 2);
  Na2O -> AddElement(O,  natoms = 1); 

  // Calcium oxide
  G4Material* CaO   = new G4Material("CaO",   density = 3.35 *g/cm3,  ncomponents = 2);
  CaO -> AddElement(Ca, natoms = 1);
  CaO -> AddElement(O,  natoms = 1); 

  // Potasium oxide
  G4Material* K2O   = new G4Material("K2O",   density = 2.33 *g/cm3,  ncomponents = 2);
  K2O -> AddElement(K, natoms = 2);
  K2O -> AddElement(O, natoms = 1); 

  // Iron oxide (FeO)
  G4Material* FeO   = new G4Material("FeO",   density = 5.74 *g/cm3,  ncomponents = 2);
  FeO -> AddElement(Fe, natoms = 1);
  FeO -> AddElement(O,  natoms = 1); 

  // Iron oxide (Fe2O3)
  G4Material* Fe2O3 = new G4Material("Fe2O3", density = 5.24 *g/cm3,  ncomponents = 2);
  Fe2O3 -> AddElement(Fe, natoms = 2);
  Fe2O3 -> AddElement(O,  natoms = 3); 

  // Carbon dioxide (CO2)
  G4Material* CO2 = new G4Material("CO2", density = 0.001977 *g/cm3,  ncomponents = 2);
  CO2 -> AddElement(C, natoms = 1);
  CO2 -> AddElement(O, natoms = 2); 

  // Magnesium oxide
  G4Material* MgO   = new G4Material("MgO",   density = 3.58 *g/cm3,  ncomponents = 2);
  MgO -> AddElement(Mg, natoms = 1);
  MgO -> AddElement(O,  natoms = 1); 

  // Titanium oxide (TiO2)
  G4Material* TiO2 = new G4Material("TiO2", density = 4.23 *g/cm3,  ncomponents = 2);
  TiO2 -> AddElement(Ti, natoms = 1);
  TiO2 -> AddElement(O,  natoms = 2); 

  // Phosphorus oxide (P2O5)
  G4Material* P2O5 = new G4Material("P2O5", density = 2.39 *g/cm3,  ncomponents = 2);
  P2O5 -> AddElement(P, natoms = 2);
  P2O5 -> AddElement(O, natoms = 5); 

  // Manganese oxide (MnO)
  G4Material* MnO = new G4Material("MnO", density = 5.03 *g/cm3,  ncomponents = 2);
  MnO -> AddElement(Mn, natoms = 1);
  MnO -> AddElement(O,  natoms = 1); 

  // Brimstone (S)
  G4Material* matS = new G4Material("matS", density = 2.07 *g/cm3,  ncomponents = 1);
  matS -> AddElement(S, natoms = 1);
  //  G4Material* S = new G4Material("S", z = 16.0, a = 32.065 *g/mole, density = 2.07 *g/cm3);

  // Rock
  G4Material* Rock = new G4Material("Rock", density = 2.70 *g/cm3, ncomponents = 14);
  Rock -> AddMaterial(SiO2,  fractionmass = 52.83  *perCent);
  Rock -> AddMaterial(Al2O3, fractionmass = 25.69  *perCent);
  Rock -> AddMaterial(CaO,   fractionmass =  4.87  *perCent);
  Rock -> AddMaterial(Na2O,  fractionmass =  5.76  *perCent);
  Rock -> AddMaterial(K2O,   fractionmass =  4.73  *perCent);
  Rock -> AddMaterial(FeO,   fractionmass =  1.27  *perCent);
  Rock -> AddMaterial(Fe2O3, fractionmass =  2.54  *perCent);
  Rock -> AddMaterial(H2O,   fractionmass =  0.25  *perCent);
  Rock -> AddMaterial(CO2,   fractionmass =  0.61  *perCent);
  Rock -> AddMaterial(MgO,   fractionmass =  0.54  *perCent);
  Rock -> AddMaterial(TiO2,  fractionmass =  0.36  *perCent);
  Rock -> AddMaterial(P2O5,  fractionmass =  0.37  *perCent);
  Rock -> AddMaterial(MnO,   fractionmass =  0.15  *perCent);
  Rock -> AddMaterial(matS,  fractionmass =  0.005 *perCent);

  // Concrete
  G4Material *Concrete = new G4Material("Concrete", density = 2.34 *g/cm3, ncomponents = 13);
  Concrete -> AddElement(H,  fractionmass =  0.938 *perCent);
  Concrete -> AddElement(O,  fractionmass = 49.645 *perCent);
  Concrete -> AddElement(Si, fractionmass = 26.089 *perCent);
  Concrete -> AddElement(Al, fractionmass =  6.282 *perCent);
  Concrete -> AddElement(Fe, fractionmass =  3.619 *perCent);
  Concrete -> AddElement(Ca, fractionmass =  8.035 *perCent);
  Concrete -> AddElement(Mg, fractionmass =  1.472 *perCent);
  Concrete -> AddElement(S,  fractionmass =  0.097 *perCent);
  Concrete -> AddElement(Na, fractionmass =  1.915 *perCent);
  Concrete -> AddElement(K,  fractionmass =  1.610 *perCent);
  Concrete -> AddElement(Ti, fractionmass =  0.278 *perCent);
  Concrete -> AddElement(P,  fractionmass =  0.005 *perCent);
  Concrete -> AddElement(Mn, fractionmass =  0.015 *perCent);

  // Glass
  // http://www.climbing-web.com/CLIMBING/goaisatu/file/glassware_feature.pdf
  // http://www.duran-glass.com/feature/chemical.html
  // Boron dioxide
  G4Material* B2O3  = new G4Material("B2O3",  density = 2.46 *g/cm3,  ncomponents = 2);
  B2O3 -> AddElement(B, natoms = 2);
  B2O3 -> AddElement(O, natoms = 3);  

  G4Material *Glass = new G4Material("Glass", density =2.34 *g/cm3, ncomponents = 4);
  Glass -> AddMaterial(SiO2,  fractionmass = 81.0 *perCent);
  Glass -> AddMaterial(B2O3,  fractionmass = 13.0 *perCent);
  Glass -> AddMaterial(Na2O,  fractionmass =  4.0 *perCent);
  Glass -> AddMaterial(Al2O3, fractionmass =  2.0 *perCent);

  // Sillion rubber + B4C 40%
  //  http://www.askcorp.co.jp/sanshin/work/engineering/pdf/material.pdf
  //-------------------------------------------------//
  const G4double R_B4C  = 40;    // target value, wt-%
  //-------------------------------------------------//
  const G4double R0_B4C = 20;    // original value, wt-%
  const G4double W0_H   = 0.065; // fraction Mass
  const G4double W0_O   = 0.173;
  const G4double W0_Si  = 0.303;
  const G4double W0_B   = 0.157;
  const G4double W0_C   = 0.302;

  G4double totalMass = R_B4C / R0_B4C * (W0_B + W0_C) + (100.0 - R_B4C) / (100.0 - R0_B4C) * (W0_H + W0_O + W0_Si);
  G4double W_H       = (100.0 - R_B4C) / (100.0 - R0_B4C) * W0_H  / totalMass;
  G4double W_O       = (100.0 - R_B4C) / (100.0 - R0_B4C) * W0_O  / totalMass;
  G4double W_Si      = (100.0 - R_B4C) / (100.0 - R0_B4C) * W0_Si / totalMass;
  G4double W_B       = R_B4C / R0_B4C * W0_B / totalMass;
  G4double W_C       = R_B4C / R0_B4C * W0_C / totalMass;

#if 0
  G4cout << "totalMass = " << totalMass << G4endl;
  G4cout << "W_H  = " << W_H  << G4endl;
  G4cout << "W_O  = " << W_O  << G4endl;
  G4cout << "W_Si = " << W_Si << G4endl;
  G4cout << "W_B  = " << W_B  << G4endl;
  G4cout << "W_C  = " << W_C  << G4endl;
#endif

  // ref. density (2015/7/30 from T.Iida)
  G4Material* RubberB4C = new G4Material("RubberB4C", density = 1.42 *g/cm3, ncomponents = 5);
  RubberB4C -> AddElement(H,  fractionmass = W_H);
  RubberB4C -> AddElement(O,  fractionmass = W_O);
  RubberB4C -> AddElement(Si, fractionmass = W_Si);
  RubberB4C -> AddElement(B,  fractionmass = W_B);
  RubberB4C -> AddElement(C,  fractionmass = W_C);

  // Print materials
  //  G4cout << G4endl << "The materials defined are : " << G4endl << G4endl;
  //  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
  // Print materials
  G4cout << G4endl << "The materials defined are : " << G4endl << G4endl;
  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
  
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
