// 2014/10/29 K.Nakajima
//
#include "CAN3PrimaryGeneratorAction.hh"

#include "G4GeneralParticleSource.hh"
#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4HEPEvtInterface.hh"
#include "Randomize.hh"
#include "G4SystemOfUnits.hh"

#include "G4TransportationManager.hh" // to get CopyNo

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3PrimaryGeneratorAction::CAN3PrimaryGeneratorAction(G4int mcType)
//CAN3PrimaryGeneratorAction::CAN3PrimaryGeneratorAction(G4int mcType, G4String particleType, G4double particleEnergy, G4String positionType)
{
  fMCType         = mcType;
  //  fParticleType   = particleType;
  //  fParticleEnergy = particleEnergy;
  //  fPositionType   = positionType;
  
   if (fMCType == 0) { // Monochromatic mode
    G4int n_particle = 1;
    fParticleGun = new G4ParticleGun(n_particle);
    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    fParticleGun -> SetParticleDefinition(particleTable -> FindParticle("gamma"));
    G4cout << "--- G4ParticleGun was called (CAN3PrimaryGeneratorAction)" << G4endl;

    // Particle type
  
  }
 else if (fMCType == 1) { // GPS mode
    fParticleSource = new G4GeneralParticleSource();
    G4cout << "--- G4GeneralParticleSource was called (CAN3PrimaryGeneratorAction)" << G4endl;
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3PrimaryGeneratorAction::~CAN3PrimaryGeneratorAction()
{
  if (fMCType == 0)
    delete fParticleGun;
  else if (fMCType == 1)
    delete fParticleSource; 
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
 
 // Monochromatic mode
  if (fMCType == 0) {
 
  //22na
  #if 0
  if (G4UniformRand()<0.18){
  fParticleGun -> SetParticleEnergy(0.511 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  
  if (G4UniformRand()<0.09994/*0.09994 is branching fraction*/){
  fParticleGun -> SetParticleEnergy(1.275 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  #endif
  //22na, test
  #if 0
  //first gamma ray
  if (G4UniformRand()<0.18){
  fParticleGun -> SetParticleEnergy(0.511 *MeV);  
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  //second gamma
  if (G4UniformRand()<0.09994/*0.09994 is branching fraction*/){
  fParticleGun -> SetParticleEnergy(1.275 *MeV);  
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent);
  }
  #endif
  //24na
  #if 0
  //first gamma ray
  if (G4UniformRand()<=0.999934){
  fParticleGun -> SetParticleEnergy(1.368 *MeV);
  
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  //second gamma
  if (G4UniformRand()<=0.99862){
  fParticleGun -> SetParticleEnergy(2.754 *MeV);
  
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent);
  }
  #endif
  //137cs
  #if 1
  if (G4UniformRand()< 0.85){
  fParticleGun -> SetParticleEnergy(0.662 *MeV);
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  // G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
   }
  if (G4UniformRand()< 0.0000058){
  fParticleGun -> SetParticleEnergy(0.284 *MeV);
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  // G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
   }

  #endif 

  //60co, test
  #if 0
  if (G4UniformRand()<0.09985){
  fParticleGun -> SetParticleEnergy(1.173 *MeV);
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  // G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
   }
  if (G4UniformRand()<0.09998){
  fParticleGun -> SetParticleEnergy(1.332 *MeV);
  G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
  G4double phi = 2.0 * M_PI * G4UniformRand();

  G4double px = sin_theta * std::cos(phi);
  G4double py = sin_theta * std::sin(phi);
  G4double pz = cos_theta;

  // G4cerr << px << "  " << py << "  " << pz << G4endl;

  fParticleGun -> SetParticleMomentumDirection(G4ThreeVector(px, py, pz));
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
   }
  #endif


  //60Co
  #if 0
  if (G4UniformRand()<0.09985){
  fParticleGun -> SetParticleEnergy(1.173 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  if (G4UniformRand()<0.09998){
  fParticleGun -> SetParticleEnergy(1.332 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  #endif

  //88Y
  #if 0
  if (G4UniformRand()>0.514){
  fParticleGun -> SetParticleEnergy(1.836 *MeV);
  }
  // fParticleGun -> GeneratePrimaryVertex(anEvent); 
  else
    // if (G4UniformRand()<0.514){
  {
  fParticleGun -> SetParticleEnergy(0.898 *MeV);
  }
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  //  }
  #endif

  //88Y
  #if 0
  if (G4UniformRand()<0.939){
  fParticleGun -> SetParticleEnergy(0.898 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  if (G4UniformRand()<0.9932){
  fParticleGun -> SetParticleEnergy(1.836 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  #endif

  //90y
  #if 0
  if (G4UniformRand()<0.1){
  fParticleGun -> SetParticleEnergy(2.318 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  #endif 

  //208Bi
  #if 0
  if (G4UniformRand()<0.1){
  fParticleGun -> SetParticleEnergy(2.610 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  #endif 

  //152Eu
  #if 0
  if (G4UniformRand()<0.2841){
  fParticleGun -> SetParticleEnergy(0.12178 *MeV);
  fParticleGun -> GeneratePrimaryVertex(anEvent); 
  }
  #endif

  //
  // Position
  //
 
  G4double x, y, z;
 

  // point source
  #if 0
  x = 3.5 *cm; //3.5 *cm; //0 *cm; //7.95 *cm; // 3.5 * cm;(center of large NaI) // 7 *cm;(test w/o lead, 20cm top of NaI)
  y = 2.0 *cm; //2.0 *cm;//6.5 *cm; //2.05 *cm; //2 * cm; // 0 *cm;
  z = -1.75 *cm; //-1.75 *cm;//3.25 *cm; //-2.45 *cm; //-1.75 * cm; // 21 *cm;
   G4cerr << x << "  " << y << "  " << z << G4endl;
 #endif
  
  // uniform in material
 #if 1
  G4Navigator* gnavi = G4TransportationManager::GetTransportationManager() -> GetNavigatorForTracking();
  G4VPhysicalVolume* physical_volume;
   //  const G4int targetCopyNo = 1; // NaI
  // const G4int targetCopyNo = 8; // PbShield
  const G4int targetCopyNo = 1; // NaI1  , =6 //NaI2
  G4int copyNo;
  //  else { 
  do {
    //  x = (1.0 - 2.0 * G4UniformRand()) * 37.5 * cm; // within PbShield
    //  y = (1.0 - 2.0 * G4UniformRand()) * 10.0 * cm; // within PbShield
    //  z = (1.0 - 2.0 * G4UniformRand()) * 12.5 * cm; // within PbShield

    //small NaI 
#if 0
    x = (5.3 + 5.3 * G4UniformRand()) * cm; // within uniform 5.3cm (NaI source cylinder 5.1x5.1cm), center point +/-(5.3/2) cm
    //  y = (1.4 + 5.3 * G4UniformRand()) * cm;
    //  z = (-0.85 + 5.3 * G4UniformRand()) * cm;
    y = (5.3 * G4UniformRand()-0.6) * cm; // within uniform 5.3cm
    z = (5.3 * G4UniformRand()-5.1) * cm; // within uniform 5.3cm
#endif
    
    //large NaI
#if 1
    z =   (2.3 + 2.0 * (1.0-2.0*G4UniformRand())) * cm; // within uniform 30cm (NaI source retangular 30x6.35x6.35cm), center point +/-(length/2) cm
    x = (-9.8 + 1.25 * (1.0-2.0*G4UniformRand())) * cm; // within uniform 6.35cm
    y =  (0.0 + 1.25 * (1.0-2.0*G4UniformRand())) * cm; // within uniform 6.35cm
#endif
  //within crystal
#if 0
    z =  (0.0 + 5.0 * (1.0-2.0*G4UniformRand())) * cm; // within uniform 10cm cube  //center of volume (+/-) spansize/2
    x =  (0.0 + 5.0 * (1.0-2.0*G4UniformRand())) * cm; // within uniform 10cm cube
    y =  (0.0 + 5.0 * (1.0-2.0*G4UniformRand())) * cm; // within uniform 10cm cube
#endif

 //2x6 inch NaI
#if 0
    x = (5.5 + 7.75 * (1.0-2.0*G4UniformRand())) * cm; // within uniform 5.3cm (NaI source cylinder 5.1x5.1cm), center point +/-(5.3/2) cm
    y = (5.3 * G4UniformRand()-0.6) * cm; // within uniform 5.3cm
    z = (5.3 * G4UniformRand()-5.1) * cm; // within uniform 5.3cm
#endif
    

    G4ThreeVector position = G4ThreeVector(x, y, z);
    physical_volume = gnavi -> LocateGlobalPointAndSetup(position, 0, false);
    copyNo = physical_volume -> GetCopyNo();
  }
  while (!(copyNo == targetCopyNo));
  G4cerr << x << "  " << y << "  " << z << G4endl;
  //  }
  #endif
  
  //cylinder source
  #if 0
  // G4double cos_theta = (1.0 - 2.0 * G4UniformRand());
  //  G4double sin_theta = sqrt(1.0 - cos_theta * cos_theta);
   G4Navigator* gnavi = G4TransportationManager::GetTransportationManager() -> GetNavigatorForTracking();
  G4VPhysicalVolume* physical_volume;
   //  const G4int targetCopyNo = 1; // NaI
  // const G4int targetCopyNo = 8; // PbShield
  const G4int targetCopyNo = 6; // Air
  G4int copyNo;
  G4double r,phi;
  do {
  r = 2.54 * G4UniformRand() ;
  phi = 2.0 * M_PI * G4UniformRand();
  //  cosphi = std::cos(phi);
  // sinphi = std::sqrt(1. - cosphi*cosphi);

  //x = (5.3 * G4UniformRand()-5.1) * std::cos(phi) *cm;
   x = (r * std::cos(phi) + 2.05) *cm;
  //x = (r * cosphi + 2.05) *cm;
  //y = (5.3 * G4UniformRand()-0.6) * std::sin(phi) *cm;
   // y = (r * std::sqrt(1. - cosTheta*cosTheta) - 2.45) *cm ;
   y = (r * std::sin(phi) - 2.45) *cm ;
   //  z = (5.1 + 5.1 * G4UniformRand()) * cm;  //2x2 inch, center 
   z = (5.5 + 5.1 * (1.0-2.0*G4UniformRand())) *cm; //2x6 inch
  //  z = (5.5 + 15.0 * (1.0-2.0*G4UniformRand())) * cm; //2x12 inch
   //  z = (5.5 + (1.0 - 2.0 * G4UniformRand() * 7.75)) * cm;
  G4ThreeVector position = G4ThreeVector(x, y, z);
  physical_volume = gnavi -> LocateGlobalPointAndSetup(position, 0, false);
  copyNo = physical_volume -> GetCopyNo();
  }
  while (!(copyNo == targetCopyNo));
  G4cerr << x << "  " << y << "  " << z << G4endl;
  #endif

  //set position condition
  fParticleGun -> SetParticlePosition(G4ThreeVector(x, y, z));
  
 }
  else if (fMCType == 1) { // GPS
    fParticleSource -> GeneratePrimaryVertex(anEvent);
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
