// 2014/05/12 K.Nakajima
//
#include "G4Run.hh"
#include "G4RunManager.hh"

#include "CAN3RunAction.hh"
#include "CAN3EventAction.hh"
#include "CAN3HistoManager.hh"

#include <fstream>
#include <iostream>
#include <sstream>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3RunAction::CAN3RunAction(CAN3HistoManager* histo)
:fHistoManager(histo)
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3RunAction::~CAN3RunAction()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3RunAction::BeginOfRunAction(const G4Run* aRun)
{ 
  G4cout << "### Run " << aRun -> GetRunID() << " start." << G4endl;
  
  //Trang add
  // inform the runManager to save random number seed
  G4RunManager::GetRunManager() -> SetRandomNumberStore(true);

  // initialize cumulative quantities
  //
  fEnergyDeposit = 0;
  
  // histograms
  //
  fHistoManager -> Book();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

//void CAN3RunAction::EndOfRunAction(const G4Run* aRun )
void CAN3RunAction::EndOfRunAction(const G4Run*)
{
  //  G4double eventNo = aRun -> GetNumberOfEvent();

  //save histograms
  //
  fHistoManager -> Save();   
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
