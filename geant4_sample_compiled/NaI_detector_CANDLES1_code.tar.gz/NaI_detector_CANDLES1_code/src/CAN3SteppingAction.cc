// 2014/05/12 K.Nakajima
//
#include "CAN3SteppingAction.hh"
#include "CAN3DetectorConstruction.hh"
#include "CAN3EventAction.hh"
#include "G4SteppingManager.hh"

#include "G4Track.hh"
#include "G4StepPoint.hh"
#include "G4UnitsTable.hh"
#include "G4VProcess.hh"
#include "G4RunManager.hh"

#include "G4SystemOfUnits.hh"

#include <iomanip>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3SteppingAction::CAN3SteppingAction(CAN3DetectorConstruction* det, CAN3EventAction* evt)
  :fDetector(det), fEventAction(evt)					 
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3SteppingAction::~CAN3SteppingAction()
{;}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3SteppingAction::UserSteppingAction(const G4Step* aStep)
//void CAN3SteppingAction::UserSteppingAction(const G4Step*)
{
  // Step ---> pre/postStepPoint
  //
  G4StepPoint* preStepPoint  = aStep -> GetPreStepPoint();
  G4StepPoint* postStepPoint = aStep -> GetPostStepPoint();

  // preStepPoint
  G4String materialName;
  if (preStepPoint -> GetPhysicalVolume() != NULL)
    materialName = preStepPoint -> GetPhysicalVolume() -> GetName(); // should be pre
  else 
    materialName = "NULL";

  // get process name
  //
  G4String preProcessName;
  if (preStepPoint -> GetProcessDefinedStep() != NULL)
    preProcessName = preStepPoint -> GetProcessDefinedStep() -> GetProcessName();
  else
    preProcessName = "UserLimit";

  G4String postProcessName;
  if (postStepPoint -> GetProcessDefinedStep() != NULL)
    postProcessName = postStepPoint -> GetProcessDefinedStep() -> GetProcessName();
  else
    postProcessName = "UserLimit";

  // Track
  G4Track* aTrack              = aStep -> GetTrack();

  const G4VProcess*  process   = aTrack -> GetCreatorProcess();
  G4String originedProcessName;
  if (process != 0)
    originedProcessName = process -> GetProcessName();
  else 
    originedProcessName = "UserLimit";

  // Track --> Particle definition
  //
  G4ParticleDefinition* parDef = aTrack -> GetDefinition();
  G4int PDGNumber              = parDef -> GetPDGEncoding();
  G4String particleName        = parDef -> GetParticleName();

  //
  // record information
  //

  // initial information
  if (preProcessName == "UserLimit" && originedProcessName == "UserLimit") {
    fEventAction -> SetInitialCopyNumber(aStep -> GetPreStepPoint() -> GetTouchableHandle() -> GetCopyNumber());
    fEventAction -> SetInitialParticlePosition(aTrack -> GetVertexPosition());
  }
    if (preProcessName == "UserLimit" && originedProcessName == "RadioactiveDecay" && (particleName == "gamma" || particleName == "e-")) {
        fEventAction -> AddInitialParticleEnergy(aTrack -> GetVertexKineticEnergy()); 
      //fEventAction -> SetInitialParticleEnergy  (aTrack -> GetVertexKineticEnergy());
    }
  

  // step information
  G4int    copyNo        = aStep -> GetPreStepPoint() -> GetTouchableHandle() -> GetCopyNumber();
  G4double energyDeposit = aStep -> GetTotalEnergyDeposit();

  // PDGNumber : 11(e-), -11(e+), 22(gamma), 1000020040(alpha)
  if (0 < energyDeposit && (PDGNumber == 11 || PDGNumber == -11 || PDGNumber == 22 || PDGNumber == 1000020040)) {

    // Ge detectorCaF2 or LS
    /*
    G4int copyNoWorld          = 9;
    G4int copyNoPbShield       = 8;
    G4int copyNoAir            = 7;
    G4int copyNoNaI1   	       = 1;
    G4int copyNoNaI2           = 6;
    G4int copyNoRock           = 1100;
    G4int copyNoBufferTank     = 1001;
    G4int copyNoBuffer         = 1002;
    G4int copyNoLSTank         = 1003;
    G4int copyNoLS             = 1004;
    G4int copyNoAcrylBox       =5;
    G4int copyNoAcrylOut       =13;
    G4int copyNoAcrylIn        =12;
    G4int copyNoWLS            =11;
    G4int copyNoCaF2           =4;
    G4int copyNoPMT1           =2;
    G4int copyNoPMT2           =3;
    */
    if (copyNo == 6) {
      G4ThreeVector position = aStep -> GetPreStepPoint() -> GetPosition();
      fEventAction -> AddEdepTimePosition(energyDeposit * position[0], energyDeposit * position[1], energyDeposit * position[2]);
      fEventAction -> AddGeEnergyDeposit(energyDeposit);
    }
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
