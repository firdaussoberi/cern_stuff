// source: $G4INSTALL/examples/extended/analysis/AnaEx02/src/HistoManager.cc
// 2014/05/12 K.Nakajima
//
#include <TH1D.h>
#include <TFile.h>
#include <TTree.h>
#include <CLHEP/Units/SystemOfUnits.h>

#include "CAN3HistoManager.hh"
#include "G4UnitsTable.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3HistoManager::CAN3HistoManager(G4String rootFileName)
  :fRootFile(0), fTree(0), fRootFileName(rootFileName)
{
  fEventID  = 0; // par01
  fNCopygen = 0; // par02
  fEgen     = 0; // par03
  fXgen     = 0; // par04
  fYgen     = 0; // par05
  fZgen     = 0; // par06
  fRgen     = 0; // par07
  fE        = 0; // par08
  fX        = 0; // par09
  fY        = 0; // par10
  fZ        = 0; // par11
  fR        = 0; // par12
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3HistoManager::~CAN3HistoManager()
{
  if (fRootFile) delete fRootFile;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3HistoManager::Book()
{ 
  // Creating a tree container to handle histograms and ntuples.
  // This tree is associated to an output file.
  //
  fRootFile = new TFile(fRootFileName, "RECREATE");
  if (!fRootFile) {
    G4cout << " CAN3HistoManager::book : problem creating the ROOT TFile " << G4endl;
    return;
  }
  G4cout << "\n----> Opened '" << fRootFileName << "'" << G4endl;
   
  // create 1 ntuple in subdirectory "ntuples"
  //
  fTree = new TTree("tree", "CANDLES3 Simulation Outpus");
  fTree -> Branch("EventID",  &fEventID,  "EventID/I");  // par01
  fTree -> Branch("NCopygen", &fNCopygen, "NCopygen/I"); // par02
  fTree -> Branch("Egen",     &fEgen,     "Egen/D");     // par03
  fTree -> Branch("Xgen",     &fXgen,     "Xgen/D");     // par04
  fTree -> Branch("Ygen",     &fYgen,     "Ygen/D");     // par05
  fTree -> Branch("Zgen",     &fZgen,     "Zgen/D");     // par06
  fTree -> Branch("Rgen",     &fRgen,     "Rgen/D");     // par07
  fTree -> Branch("E",        &fE,        "E/D");        // par08
  fTree -> Branch("X",        &fX,        "X/D");        // par09
  fTree -> Branch("Y",        &fY,        "Y/D");        // par10
  fTree -> Branch("Z",        &fZ,        "Z/D");        // par11
  fTree -> Branch("R",        &fR,        "R/D");        // par12
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3HistoManager::Save()
{ 
  if (fRootFile) {
    fRootFile -> Write(); // Writing the histograms to the file
    fRootFile -> Close(); // and closing the tree (and the file)
    G4cout << "----> Tree is saved. \n" << G4endl;
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3HistoManager::FillNtuple(G4int    EventID,  // par01
				  G4int    NCopygen, // par02
				  G4double Egen,     // par03
				  G4double Xgen,     // par04
				  G4double Ygen,     // par05
				  G4double Zgen,     // par06
				  G4double Rgen,     // par07
				  G4double E,        // par08
				  G4double X,        // par09
				  G4double Y,        // par10
				  G4double Z,        // par11
				  G4double R)        // par12
{
  fEventID   = EventID;  // par01
  fNCopygen  = NCopygen; // par02 
  fEgen      = Egen;     // par03 
  fXgen      = Xgen;     // par04 
  fYgen      = Ygen;     // par05 
  fZgen      = Zgen;     // par06 
  fRgen      = Rgen;     // par07 
  fE         = E;        // par08
  fX         = X;        // par09
  fY         = Y;        // par10
  fZ         = Z;        // par11
  fR         = R;        // par12

  if (fTree) fTree -> Fill();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
