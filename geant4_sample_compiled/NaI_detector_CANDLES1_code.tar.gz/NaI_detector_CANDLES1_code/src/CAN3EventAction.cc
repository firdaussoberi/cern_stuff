// 2014/05/12 K.Nakajima
//
#include "CAN3EventAction.hh"
#include "CAN3HistoManager.hh"

#include "G4Event.hh"
#include "G4HCofThisEvent.hh"
#include "G4TrajectoryContainer.hh"
#include "G4VVisManager.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
#include "G4TrajectoryPoint.hh"
#include "G4SystemOfUnits.hh"

#include <iomanip>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3EventAction::CAN3EventAction(CAN3RunAction* run, CAN3PrimaryGeneratorAction* primary, CAN3HistoManager* histo)
{
  fRunAction              = run;
  fPrimaryGeneratorAction = primary;
  fHistoManager           = histo;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CAN3EventAction::~CAN3EventAction()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3EventAction::BeginOfEventAction(const G4Event* evt)
{  
  fEventID = evt -> GetEventID(); // par1
  if (fEventID % 10000 == 0) { 
    G4cout << "Begin of event: " << fEventID << G4endl;
  } 
  SetEventID(fEventID);

  //
  // itinialize output parameters
  //

  //  fEventID;
  fInitialCopyNumber       = 0;
  fInitialParticleEnergy   = 0;
  fInitialParticlePosition.set(0,0,0);

  // step information
  fGeEnergyDeposit         = 0;
  fEdepTimePositionX       = 0;
  fEdepTimePositionY       = 0;
  fEdepTimePositionZ       = 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3EventAction::EndOfEventAction(const G4Event* evt)
{
  G4int eventID                  = fEventID;                     // par01

  // initial information
  G4int    initialCopyNumber     = fInitialCopyNumber;           // par02
  G4double initialParticleEnergy = fInitialParticleEnergy / keV; // par03
			      
  G4double Xgen  = fInitialParticlePosition.x() / cm;            // par04
  G4double Ygen  = fInitialParticlePosition.y() / cm;            // par05
  G4double Zgen  = fInitialParticlePosition.z() / cm;            // par06
  G4double Rgen  = sqrt(Xgen*Xgen + Ygen*Ygen + Zgen*Zgen);      // par07

  // energy deposit information
  G4double GeEnergyDeposit       = 0;
  G4double X                     = 0;
  G4double Y                     = 0;
  G4double Z                     = 0;
  G4double R                     = 0;

  GeEnergyDeposit  = fGeEnergyDeposit / keV;         // par08

  if (GeEnergyDeposit) {
    X  = fEdepTimePositionX / fGeEnergyDeposit / cm; // par09
    Y  = fEdepTimePositionY / fGeEnergyDeposit / cm; // par10
    Z  = fEdepTimePositionZ / fGeEnergyDeposit / cm; // par11
    R  = sqrt(X*X + Y*Y + Z*Z);                      // par12
  }

  if (GeEnergyDeposit) {
    fHistoManager -> FillNtuple(eventID,               // par01
				initialCopyNumber,     // par02
				initialParticleEnergy, // par03
				Xgen,                  // par04
				Ygen,                  // par05
				Zgen,                  // par06
				Rgen,                  // par07
				GeEnergyDeposit,       // par08
				X,                     // par09
				Y,                     // par10
				Z,                     // par11
				R);                    // par12
  }
  //---------------------------------------------------------------------//

  //
  // Visualization -->
  //
  G4VVisManager* pVisManager = G4VVisManager::GetConcreteInstance();
  if (pVisManager) {
    G4TrajectoryContainer* trajectoryContainer = evt -> GetTrajectoryContainer();
    G4int n_trajectories = 0;
    if (trajectoryContainer)  n_trajectories = trajectoryContainer -> entries();
	
    G4Colour colour;
    G4VisAttributes lineAttributes = G4VisAttributes();
    for (G4int i = 0; i < n_trajectories; i++) {
      G4Polyline* lines         = new G4Polyline();
      G4Polymarker* steps       = new G4Polymarker();
      G4Polymarker* auxiliaries = new G4Polymarker();

      G4VTrajectory* trajectory = (*trajectoryContainer)[i];
      TraceTrajectory(trajectory, lines, steps, auxiliaries);
      G4String particleName = trajectory -> GetParticleName();

      if      (particleName == "neutron")	SetColour(colour, "green");
      else if (particleName == "gamma")	        SetColour(colour, "blue");
      else if (particleName == "e-")            SetColour(colour, "yellow");
      else if (particleName == "proton") 	SetColour(colour, "gray");
      else if (particleName == "opticalphoton") SetColour(colour, "cyan");
      else if (particleName == "mu-") 	        SetColour(colour, "white");
      else 					SetColour(colour, "red");

      lineAttributes.SetColour(colour);
      lines -> SetVisAttributes(&lineAttributes);
      pVisManager -> Draw(*lines);

      delete lines;
      delete steps;
      delete auxiliaries;
    }
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3EventAction::TraceTrajectory(G4VTrajectory* trajectory,
                                      G4Polyline* lines, G4Polymarker* steps, G4Polymarker* auxiliaries)
{
  for (G4int i = 0; i < trajectory -> GetPointEntries(); i++) {  //GetPointEntries():Returns the number of tarjectory points

    G4VTrajectoryPoint* point = trajectory -> GetPoint(i);
    const std::vector<G4ThreeVector>* auxiliaryPoints = point -> GetAuxiliaryPoints();

    if (auxiliaryPoints) {
      for (size_t j = 0; j<auxiliaryPoints -> size(); j++) {
	const G4ThreeVector position((*auxiliaryPoints)[j]);
	lines -> push_back(position);
	auxiliaries -> push_back(position);
      }
    }
    const G4ThreeVector position(point -> GetPosition());
    lines -> push_back(position);
    steps -> push_back(position);
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CAN3EventAction::SetColour(G4Colour& colour, G4String colourName)
{
  if (colourName == "white") {
    colour = G4Colour(1.0, 1.0, 1.0);
  }
  else if (colourName == "gray") {
    colour = G4Colour(0.5, 0.5, 0.5);
  }
  else if (colourName == "black") {
    colour = G4Colour(0.0, 0.0, 0.0);
  }
  else if (colourName == "red") {
    colour = G4Colour(1.0, 0.0, 0.0);
  }
  else if (colourName == "green") {
    colour = G4Colour(0.0, 1.0, 0.0);
  }
  else if (colourName == "blue") {
    colour = G4Colour(0.0, 0.0, 1.0);
  }
  else if (colourName == "cyan") {
    colour = G4Colour(0.0, 1.0, 1.0);
  }
  else if (colourName == "magenta") {
    colour = G4Colour(1.0, 0.0, 0.0);
  }
  else if (colourName == "yellow") {
    colour = G4Colour(1.0, 1.0, 0.0);
  }
  else {
    // Default colour is "brack"
    colour = G4Colour(0.0, 0.0, 0.0);
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
