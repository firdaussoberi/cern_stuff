// 2014/05/12 K.Nakajima
//
#ifndef CAN3PrimaryGeneratorAction_h
#define CAN3PrimaryGeneratorAction_h 1

#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4ThreeVector.hh"

class G4GeneralParticleSource;
class G4ParticleGun;
class G4Event;
class G4VPrimaryGenerator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class CAN3PrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction
{
public:
  // CAN3PrimaryGeneratorAction(G4int mcType);
  CAN3PrimaryGeneratorAction(G4int mcType);
  ~CAN3PrimaryGeneratorAction();

  void GeneratePrimaries(G4Event* anEvent);

private:
  G4ParticleGun* fParticleGun;
  G4GeneralParticleSource* fParticleSource; // use General Particle Source
  G4VPrimaryGenerator*     fHEPEvent;       // use HEPEvent

  G4bool fUseGPS;

  G4int    fMCType;
  //  G4String fParticleType;
  //  G4double fParticleEnergy;
  //  G4String fPositionType;
};

#endif

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
