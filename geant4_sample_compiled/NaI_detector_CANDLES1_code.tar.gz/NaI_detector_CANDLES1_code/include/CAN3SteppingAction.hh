// 2014/05/12 K.Nakajima
// 
#ifndef CAN3SteppingAction_h
#define CAN3SteppingAction_h 1

#include "G4UserSteppingAction.hh"
#include "globals.hh"

#include "fstream" // for output

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

class CAN3DetectorConstruction;
class CAN3EventAction;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

class CAN3SteppingAction : public G4UserSteppingAction
{
public:
  CAN3SteppingAction(CAN3DetectorConstruction*, CAN3EventAction*);
  ~CAN3SteppingAction();

  void UserSteppingAction(const G4Step*);

private:
  CAN3DetectorConstruction* fDetector;
  CAN3EventAction*          fEventAction;
  
  std::ofstream *fOut;
  
};

#endif

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
