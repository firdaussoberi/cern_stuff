// source: geant4.9.6.p01/examples/novice/N04/include/ExN04EventAction.hh
// 2014/05/12 K.Nakajima
//
#ifndef CAN3EventAction_h
#define CAN3EventAction_h 1

#include "CAN3RunAction.hh"
#include "CAN3PrimaryGeneratorAction.hh"
#include "CAN3HistoManager.hh"

#include "G4UserEventAction.hh"
#include "G4VTrajectory.hh"
#include "G4Polyline.hh"
#include "G4Polymarker.hh"
#include "G4Colour.hh"

#include <vector>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class CAN3EventAction : public G4UserEventAction
{
public:
  CAN3EventAction(CAN3RunAction*, CAN3PrimaryGeneratorAction*, CAN3HistoManager*);
  ~CAN3EventAction();

  void BeginOfEventAction(const G4Event*);
  void EndOfEventAction  (const G4Event*);

  void TraceTrajectory(G4VTrajectory*, G4Polyline*, G4Polymarker*, G4Polymarker*);
  void SetColour(G4Colour&, G4String);

  //
  // original
  //
  inline void  SetEventID                         (G4int EventID)                         {fEventID = EventID;};
  inline G4int GetEventID()                                                               {return fEventID;};

  // initial information			    					    						
  inline void          SetInitialCopyNumber       (G4int         initialCopyNumber)       {fInitialCopyNumber        = initialCopyNumber;};
  inline void          SetInitialParticleEnergy   (G4double      initialParticleEnergy)   {fInitialParticleEnergy    = initialParticleEnergy;};
  inline void          SetInitialParticlePosition (G4ThreeVector initialParticlePosition) {fInitialParticlePosition  = initialParticlePosition;};
  inline void          AddInitialParticleEnergy   (G4double      initialParticleEnergy)   {fInitialParticleEnergy   += initialParticleEnergy;};

  // deposit information
  inline void          AddGeEnergyDeposit         (G4double GeEnergyDeposit)              {fGeEnergyDeposit          += GeEnergyDeposit;};
  inline void          AddEdepTimePosition        (G4double EdepTimePositionX, G4double EdepTimePositionY, G4double EdepTimePositionZ) {
    fEdepTimePositionX += EdepTimePositionX;
    fEdepTimePositionY += EdepTimePositionY;
    fEdepTimePositionZ += EdepTimePositionZ;
  };

private:
  CAN3RunAction*              fRunAction;
  CAN3HistoManager*           fHistoManager;
  CAN3PrimaryGeneratorAction* fPrimaryGeneratorAction;

  //
  // original
  //
  G4int         fEventID;

  // initial information
  G4int         fInitialCopyNumber;
  G4double      fInitialParticleEnergy;
  G4ThreeVector fInitialParticlePosition;

  // energy deposit information
  G4double      fGeEnergyDeposit;
  G4double      fEdepTimePositionX;
  G4double      fEdepTimePositionY;
  G4double      fEdepTimePositionZ;
};

#endif

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

