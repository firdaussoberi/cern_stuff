// 2014/10/29 K.Nakajima
//
#ifndef CAN3DetectorConstruction_h
#define CAN3DetectorConstruction_h 1

class G4Box;
class G4Tubs;
class G4Trd;
class G4LogicalVolume;
class G4Material;
class G4SubtractionSolid;

#include "G4VUserDetectorConstruction.hh"
#include "G4ThreeVector.hh"
#include "G4Colour.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class CAN3DetectorConstruction : public G4VUserDetectorConstruction
{
public:
  CAN3DetectorConstruction();
  ~CAN3DetectorConstruction();

  G4VPhysicalVolume* Construct();
  void DefineMaterials();

private:

  //
  // Material
  // 
/*  G4Material* fWorldMaterial;
  G4Material* fPbShieldMaterial;
  G4Material* fAirMaterial;
  G4Material* fNaIMaterial;
  G4Material* fNaMaterial;*/
  G4Material* WorldMaterial;
  G4Material* VacuumMaterial;
  G4Material* PbShieldMaterial;
  G4Material* AirMaterial;
  G4Material* NaIMaterial;          
  G4Material* NaMaterial;           
  G4Material* LSMaterial;           
  G4Material* PMTMaterial;          
  G4Material* AcrylBoxMaterial;     
  G4Material* WLSMaterial;          
  G4Material* CaF2Material;         
  G4Material* CrystalMaterial;       
  G4Material* WaterMaterial;        
  G4Material* RockMaterial;          
  G4Material* SUSMaterial;           
  G4Material* LSTankMaterial;        

  //
  // Colour
  //
  G4Colour white;
  G4Colour grey;
  G4Colour red;
  G4Colour green;
  G4Colour blue;
  G4Colour  black;  
  G4Colour  cyan;   
  G4Colour  yellow; 
  G4Colour magenta;  
  G4Colour brown;

};

#endif

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
