// source: $G4INSTALL/examples/extended/analysis/AnaEx02/include/HistoManager.hh
// 2014/05/12 K.Nakajima
//
#ifndef CAN3HistoManager_h
#define CAN3HistoManager_h 1

#include "globals.hh"
#include <vector>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class TFile;
class TTree;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class CAN3HistoManager
{
public:
  
  CAN3HistoManager(G4String fRootFileName);
  ~CAN3HistoManager();
   
  void Book();
  void Save();

  void FillNtuple(G4int    EventID,  // par01
		  G4int    NCopygen, // par02
		  G4double Egen,     // par03
		  G4double Xgen,     // par04
		  G4double Ygen,     // par05
		  G4double Zgen,     // par06
		  G4double Rgen,     // par07
		  G4double E,        // par08
		  G4double X,        // par09
		  G4double Y,        // par10
		  G4double Z,        // par11
		  G4double R);       // par12

private:
  TFile*   fRootFile;
  TTree*   fTree;
  G4String fRootFileName;

  G4int    fEventID;    // par01, general info
  G4int    fNCopygen;   // par02, initial info 
  G4double fEgen;       // par03, initial info 
  G4double fXgen;       // par04, initial info 
  G4double fYgen;       // par05, initial info 
  G4double fZgen;       // par06, initial info 
  G4double fRgen;       // par07, initial info 
  G4double fE;          // par08, deposit info
  G4double fX;          // par09, deposit info
  G4double fY;          // par10, deposit info
  G4double fZ;          // par11, deposit info
  G4double fR;          // par12, deposit info
};

      //....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
