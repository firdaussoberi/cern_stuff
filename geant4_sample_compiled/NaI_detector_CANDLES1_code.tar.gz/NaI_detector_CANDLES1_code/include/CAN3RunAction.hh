// 2014/05/12 K.Nakajima
//
#ifndef CAN3RunAction_h
#define CAN3RunAction_h 1

#include "G4UserRunAction.hh"
#include "globals.hh"

class G4Run;
class CAN3HistoManager;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class CAN3RunAction : public G4UserRunAction
{
public:
  CAN3RunAction(CAN3HistoManager*);
  ~CAN3RunAction();

  void BeginOfRunAction(const G4Run*);
  void EndOfRunAction(const G4Run*);
  //Trang add
  void FillPerEvent(G4double, G4double, G4double, G4double); 

private:
  CAN3HistoManager* fHistoManager;

  G4int    fEventID;
  G4double fEnergyDeposit;
};

#endif

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
