#ifndef __CINT__
#include "TApplication.h"
#include "TCanvas.h"
#include "TFile.h"
#include "TH1D.h"
#include "TROOT.h"
#include "TStyle.h"
#include "TTree.h"
#endif
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cstdlib>
using namespace std;


Int_t root_histogram()
{  
  //---------------------------------------//
  TString fin_name = "output/hoge.root";
  //---------------------------------------//

  // set canvas style
  //
  gStyle -> SetOptStat(1);            // statistical information (0 = no info, 1 = show info)
  gStyle -> SetStatX(0.9);            // x position of stat info
  gStyle -> SetStatY(0.9);            // y position of stat info
  gStyle -> SetLabelSize(0.05, "XY"); // axis label font size
  gStyle -> SetTitleSize(0.06, "XY"); // axis title font size
  gStyle -> SetTitleOffset(1.0, "X"); // x title offset from axis
  gStyle -> SetTitleOffset(1.1, "Y"); // y title offset from axis
  gStyle -> SetPadLeftMargin(0.14);   // canbas left margin
  gStyle -> SetPadBottomMargin(0.14); // canbas bottom margin

  // make canvas
  //
  TCanvas *c1 = new TCanvas("c1", "", 800, 600); // x-size, y-size = 800, 600
  c1 -> SetFillStyle(4001); // canvas with transparent background 
  c1 -> SetLogy();          // set log axis

  // read input file
  //
  TFile *tfile = new TFile(fin_name);
  if (tfile -> GetNkeys() == 0) {
    cerr << "Error: don't exist such file, " << fin_name << " !" << endl;
    exit(8);
  }

  // get tree object
  TTree *tree = (TTree *)tfile -> Get("tree");
  if (tree == NULL) {
    cerr << "tree == NULL" << endl;
    exit(8);
  }

  // make histogram
  //
  const Double_t XMIN   = 0;
  const Double_t XMAX   = 4200;
  const Double_t XWIDTH = 1.0;
  Int_t bin = (Int_t)((XMAX - XMIN) / XWIDTH + 0.5);
  TH1D *h1 = new TH1D("h1", "", bin, XMIN, XMAX);
  h1 -> SetXTitle("Energy [keV]");
  if (XWIDTH == 1.0)
    h1 -> SetYTitle("Events/keV");
  else 
  h1 -> SetYTitle(Form("Events/%.0fkeV", XWIDTH));

  // fill histogram
  tree -> Draw("E >> h1");

  cout << endl
       << "Input       = " << fin_name           << endl
       << "# of events = " << h1 -> GetEntries() << endl
       << endl;
 cout << endl
       << "Input       = " << fin_name           << endl
       << "# of events = " << h1 -> GetEntries() << endl
       << "peak1=  " << h1 -> GetBinContent(1369)<< endl
       << "peak2 = " << h1 -> GetBinContent(2755) << endl
       << "peak3 = " << h1 -> GetBinContent(511) << endl
       << endl;
  // draw histogram
  //
  h1 -> SetLineColor(4); // 2: red, 3: green, 4: blue
  h1 -> SetLineWidth(2);
  h1 -> Draw();
 
  // make plot
  //
  c1 -> Print("plot_test_histogram.ps");
}


#ifndef __CINT__
Int_t main(Int_t argc, char** argv) {
  TApplication app("App", &argc, argv);
  root_histogram();
  cerr << "Finished." << endl;
  app.Run();
  return 0;
}
#endif
