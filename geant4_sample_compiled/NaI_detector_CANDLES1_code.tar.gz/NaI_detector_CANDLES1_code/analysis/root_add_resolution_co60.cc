#ifndef __CINT__
#include "TApplication.h"
#include "TAxis.h"
#include "TCanvas.h"
#include "TF1.h"
#include "TFile.h"
#include "TH1D.h"
#include "TMath.h"
#include "TRandom.h"
#include "TROOT.h"
#include "TStyle.h"
#include "TTree.h"
#endif
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
using namespace std;


Int_t root_add_resolution_co60()
{
  //-----------------------------------------//
  TString fin_name = "output/60co.root";
  //  const Double_t RESOLUTION = 0.04075112; // @ 1.275MeV
  const Double_t RESOLUTION = 0.04085106; // @ 1.275MeV
  //-----------------------------------------//

  // set canvas style
  //
  gStyle -> SetOptStat(0);
  gStyle -> SetOptFit(1111);
  gStyle -> SetStatX(0.9);
  gStyle -> SetStatY(0.9);
  gStyle -> SetLabelSize(0.05, "XY");
  gStyle -> SetTitleSize(0.06, "XY");
  gStyle -> SetTitleOffset(1.0, "X");
  gStyle -> SetTitleOffset(1.1, "Y");
  gStyle -> SetPadLeftMargin(0.14);  
  gStyle -> SetPadBottomMargin(0.14);

  // make canvas
  //
  TCanvas *c1 = new TCanvas("c1", "", 800, 600);
  c1 -> SetFillStyle(4001);
  //  c1 -> SetLogy();

  // read input file
  //
  TFile *tfile = new TFile(fin_name);
  if (tfile -> GetNkeys() == 0) {
    cerr << "Error: don't exist such file, " << fin_name << " !" << endl;
    exit(8);
  }

  TTree *tree = (TTree *)tfile -> Get("tree");
  if (tree == NULL) {
    cerr << "tree == NULL" << endl;
    exit(8);
  }

  Int_t EventID;
  Int_t NCopygen;
  Double_t Egen;
  Double_t Xgen;
  Double_t Ygen;
  Double_t Zgen;
  Double_t Rgen;
  Double_t E;
  Double_t X;
  Double_t Y;
  Double_t Z;
  Double_t R;
  tree -> SetBranchAddress("EventID",  &EventID);
  tree -> SetBranchAddress("NCopygen", &NCopygen);
  tree -> SetBranchAddress("Egen",     &Egen);
  tree -> SetBranchAddress("Xgen",     &Xgen);
  tree -> SetBranchAddress("Ygen",     &Ygen);
  tree -> SetBranchAddress("Zgen",     &Zgen);
  tree -> SetBranchAddress("Rgen",     &Rgen);
  tree -> SetBranchAddress("E",        &E);
  tree -> SetBranchAddress("E",        &E);
  tree -> SetBranchAddress("X",        &X);
  tree -> SetBranchAddress("Y",        &Y);
  tree -> SetBranchAddress("Z",        &Z);
  tree -> SetBranchAddress("R",        &R);
  tree -> GetEntry(0);		      

  // make histogram
  //
  const Double_t XMIN   = 0;
  const Double_t XMAX   = 3000;
  const Double_t XWIDTH = 10;
  Int_t bin = (Int_t)((XMAX - XMIN) / XWIDTH + 0.5);
  TH1D *h1 = new TH1D("h1", "", bin, XMIN, XMAX);
  h1 -> SetXTitle("Energy (keV)");
  if (XWIDTH == 1.0)
    h1 -> SetYTitle("Events/keV");
  else 
  h1 -> SetYTitle(Form("Events/%.0fkeV", XWIDTH));

  // give resolution
  //
  Double_t Esigma, Eres;
  for (Int_t i = 0; i < tree -> GetEntries(); i++) {
    tree -> GetEntry(i);

    if (E == 0) continue;

    // give resolution
    Esigma = RESOLUTION * TMath::Sqrt(E / 1275.0);
    Eres  = gRandom -> Gaus(E / 1275.0, Esigma) * 1275.0;

    h1 -> Fill(Eres);
  }

  cout << endl
       << "Input       = " << fin_name           << endl
       << "# of events = " << h1 -> GetEntries() << endl
       << endl;

  //
  // draw
  //

  // draw histogram
  //
  h1 -> SetLineColor(4); // 2: red, 3: green, 4: blue
  h1 -> SetLineWidth(2);
  h1 -> Draw();

  TAxis *axis = h1 -> GetXaxis();
  Int_t bmin = axis -> FindBin(3860);
  Int_t bmax = axis -> FindBin(4360);
  Double_t integral = h1 -> Integral(bmin,bmax);
  cout << endl
       << "bmin =" << setw(7) << bmin << endl
       << "bmax =" << setw(7) << bmax << endl
       << "integral =" << setw(7) << integral << endl; 


#if 1
  // fit
  //
  const Double_t FIT_XMIN =1275;//2550;//2550;//1200;//2550;//2550; //1200;//1200;//2500;// 1200;//2570;
  const Double_t FIT_XMAX =1550;//2950;//2950;//1550; //2950;//2950;//1550;//1500;//3050;//1500;//2920;
  TF1 *f1 = new TF1("f1", "gaus(0)+exp([3]+[4]*x)", FIT_XMIN, FIT_XMAX);
  f1 -> SetLineColor(2);
  f1 -> SetParameter(0,2000);
  f1 -> SetParameter(1,1332);
  f1 -> SetParameter(2,50);
  f1 -> SetParameter(3,6);
  f1 -> SetParameter(4,-0.001);
  f1 -> SetLineColor(2);
  f1 -> SetLineWidth(5);
  h1 -> Fit("f1", "R","same");

    // Draw fitting function   
    //Gaussion function 
    TF1 *f_gaus = new TF1("f_gaus", "gaus", FIT_XMIN, FIT_XMAX);
    // TF1 *f_gaus = new TF1("f_gaus", "gaus", 0, 4000);
    f_gaus -> SetParameter(0, f1 -> GetParameter(0));
    f_gaus -> SetParameter(1, f1 -> GetParameter(1));
    f_gaus -> SetParameter(2, f1 -> GetParameter(2));
    f_gaus -> SetLineColor(8);
    f_gaus -> SetLineStyle(2);
    f_gaus -> SetLineWidth(5);
    f_gaus -> Draw("same");

    //Exponential function     
    TF1 *f_expo = new TF1("f_expo", "exp([0]+[1]*x)", FIT_XMIN, FIT_XMAX);
    f_expo -> SetParameter(0, f1 -> GetParameter(3));
    f_expo -> SetParameter(1, f1 -> GetParameter(4));
    //  f_expo -> SetParameter(2, f1 -> GetParameter(2));
    f_expo -> SetLineColor(8);
    f_expo -> SetLineStyle(2);
    f_expo -> SetLineWidth(5);
    f_expo -> Draw("same");

  // get result
  Double_t height    = f1 -> GetParameter(0);
  Double_t heightE   = f1 -> GetParError(0);
  Double_t mean      = f1 -> GetParameter(1);
  Double_t meanE     = f1 -> GetParError(1);
  Double_t sigma     = f1 -> GetParameter(2);
  Double_t sigmaE    = f1 -> GetParError(2);
  // Double_t integral2  = h1 -> Integral(FIT_XMIN, FIT_XMAX)      / XWIDTH;
 Double_t integral2  = f1 -> Integral(FIT_XMIN, FIT_XMAX)      / XWIDTH;
  Double_t integral2E = f1 -> IntegralError(FIT_XMIN, FIT_XMAX) / XWIDTH;

  cout << endl
       << "Fit Result"                                                                           << endl
       << "Height   = " << setw(7) << height    << " +/- " << setw(9) << heightE                 << endl
       << "Mean     = " << setw(7) << mean     << " +/- " << setw(9) << meanE     << " [keV]"    << endl
       << "Sigma    = " << setw(7) << sigma    << " +/- " << setw(9) << sigmaE    << " [keV]"    << endl
       << "Integral = " << setw(7) << integral2 << " +/- " << setw(9) << integral2E << " [events]" << endl
       << endl;
#endif

  // make plot
  //
  c1 -> Print("plot/co60_peak1_square_self_off.ps");
  // c1 -> Print("plot/test.pdf");

  return 0;
}


#ifndef __CINT__
Int_t main(Int_t argc, char** argv) {
  TApplication app("App", &argc, argv);
  root_add_resolution_co60();
  cerr << "Finished." << endl;
  app.Run();
  return 0;
}
#endif
