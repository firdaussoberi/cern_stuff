#include "TROOT.h"
#include "TSystem.h"

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
using namespace std;


Int_t main(Int_t argc, Char_t** argv) 
{
  TROOT root("root", "root");

//  const Int_t FN = 1000;
  const Int_t FN = 1;

#if 1
  TString type = "NaI_test_1e8_co60";
#endif
#if 0
  TString type = "rock_uni";
#endif
#if 0
  TString type = "rock2_uni";
#endif
#if 0
  TString type = "SUS304_uni";
#endif

#if 0
  TString type = "rock_side";
#endif
#if 0
  TString type = "rock2_side";
#endif
#if 0
  TString type = "SUS304_side";
#endif
#if 0
  TString type = "Ni_side";
#endif
#if 0
  TString type = "Si_side";
#endif
#if 0
  TString type = "Cf_gamma_func_side";
#endif

  // make each script file
  //
  TString qsub_file = Form("../qsub_%s.sh", type.Data());
  //TString qsub_file = Form("./qsub_%s.sh", type.Data());
  ofstream fout2(qsub_file.Data());
  fout2 << "#! /bin/bash" << endl
        << endl;

  for (Int_t i = 0; i < FN; i++) {

    //    TString script_name = Form("job_run_%s_%02d.sh", type.Data(), i);
    //TString script_name = Form("job_run_%s_%03d.sh", type.Data(), i);
    TString script_name = Form("job_%s_%03d.sh", type.Data(), i);

    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_no_shield_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_10inch_no_shield_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_without_PMT_rock_tube_no_shield_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb2cm_all_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb5cm_all_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb2cm_side_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb5cm_side_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb5cm_3m_Pb2cm_1m_side_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb2cm_1m_Pb5cm_2m_Pb2cm_1m_side_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb2cm_1m_Pb4cm_2m_Pb2cm_1m_side_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb5cm_middle_2m_side_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb2cm_top_Pb10cm_3m_Pb2cm_1m_side_Pb5cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb0cm_top_Pb10cm_3m_Pb5cm_1m_side_Pb5cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb5cm_top_Pb10cm_3m_Pb5cm_1m_side_Pb5cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb5cm_top_Pb10cm_side_Pb5cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb7cm_top_Pb10cm_side_Pb7cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb5cm_top_Pb13cm_side_Pb5cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb10cm_top_Pb13cm_side_Pb10cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb10cm_top_Pb15cm_side_Pb10cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb2cm_top_Pb10cm_3m_Pb5cm_1m_side_Pb5cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_Pb10cm_3m_Pb2cm_1m_side_Pb5cm_bottom_1e7_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_1e6_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_1e6_%03d.root", type.Data(), i);
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_final_design_1e7_%03d.root", type.Data(), i);
    //TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_5m_thickness_no_shield_1e7_%03d.root", type.Data(), i);
   TString output_name = Form("/home/firdaus9/Misc/mygeant4/simulation-NaI/NaI_detector/build/root_%s.root", type.Data());

    //    TString command     = Form("time ./CANDLES3 mac/run_1e6.mac 2 %s %s", output_name.Data(), type.Data());
    //TString command     = Form("time ./CANDLES3 mac/run_1e8.mac 2 %s %s", output_name.Data(), type.Data());
   TString command     = Form("time ./CANDLES3 mac/run_1e8.mac 0 %s 2>/home/firdaus9/Misc/mygeant4/simulation-NaI/NaI_detector/build/hoge", output_name.Data());

    // SUS
    //    TString output_name = Form("/np1c/v01/candles/CANUG/USER/kyohei/MC/root_%s_IAEA_with_PMT_rock_tube_no_shield_1e6_%03d.root", type.Data(), i);
    //    TString command     = Form("time ./CANDLES3 mac/run_1e6.mac 2 %s %s", output_name.Data(), type.Data());

    //    TString Ctype       = "CM";
    //    if (i < 10)
    //      Ctype = "CL";

    ofstream fout(script_name);
    cout << setw(2) << i << "  " << script_name << endl;

    fout << "#! /bin/bash"                              << endl
	 << "#PBS -q CM"                                << endl << endl
      //      	 << "#PBS -q CL"                                << endl << endl
      //	 << "#PBS -q " << Ctype                         << endl
	 //<< "source /home/candles/local/setup/setup.sh" << endl
	 << "source /home/firdaus9/setup.sh" << endl
	 << "cd $PBS_O_WORKDIR"                         << endl << endl
	 << command                                     << endl
	 << endl;

    fout2 << "qsub job_script/" << script_name << endl
	  << "sleep 2" << endl;
  }
  cout << endl
       << "qsub file: " << qsub_file << endl;

  gSystem -> Exec("chmod a+x *sh ../*sh");
  //gSystem -> Exec("chmod a+x *sh ./qsub*sh");

  return 0;
}
