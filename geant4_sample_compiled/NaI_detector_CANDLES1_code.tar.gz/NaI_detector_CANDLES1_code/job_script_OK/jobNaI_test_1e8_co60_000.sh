#! /bin/bash
#PBS -q CM

source /home/firdaus9/setup.sh
cd $PBS_O_WORKDIR

time ./CANDLES3 mac/run_1e8.mac 0 /home/firdaus9/Misc/mygeant4/simulation-NaI/NaI_detector/build/root_NaI_test_1e8_co60.root 2>/home/firdaus9/Misc/mygeant4/simulation-NaI/NaI_detector/build/hoge

