#include "TROOT.h"
#include "TSystem.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
using namespace std;


Int_t main(Int_t argc, Char_t** argv) 
{
  TROOT root("root", "root");

  //const Int_t FN = 1000;
  const Int_t FN = 1;

#if 1
  TString type = "NaI_test_1e8_co60";
#endif
#if 0
  TString type = "rock_side";
#endif
#if 0
  TString type = "rock2_side";
#endif
#if 0
  TString type = "SUS304_side";
#endif
#if 0
  TString type = "Ni_side";
#endif
#if 0
  TString type = "Si_side";
#endif
#if 0
  TString type = "Cf_gamma_func_side";
#endif

  // make each script file
  //
  TString qsub_file = Form("../qsub_%s.sh", type.Data());
  ofstream fout2(qsub_file.Data());
  fout2 << "#! /bin/bash" << endl
        << endl;

  for (Int_t i = 0; i < FN; i++) {

    TString script_name = Form("job%s_%03d.sh", type.Data(), i);
    TString output_name = Form("/home/firdaus9/Misc/mygeant4/simulation-NaI/NaI_detector/build/root_%s.root", type.Data());
    TString command     = Form("time ./CANDLES3 mac/run_1e8.mac 0 %s 2>/home/firdaus9/Misc/mygeant4/simulation-NaI/NaI_detector/build/hoge", output_name.Data());

    //output job script
    ofstream fout(script_name);
    cout << setw(2) << i << "  " << script_name << endl;

    fout << "#! /bin/bash"                              << endl
	 << "#PBS -q CM"                                << endl << endl
      // << "#PBS -q CL"                        << endl << endl
      // << "#PBS -q " << Ctype                         << endl
	 << "source /home/firdaus9/setup.sh" << endl
	 << "cd $PBS_O_WORKDIR"                         << endl << endl
	 << command                                     << endl
	 << endl;

    fout2 << "qsub job_script/" << script_name << endl
	  << "sleep 2" << endl;
  }
  cout << endl
       << "qsub file: " << qsub_file << endl;

  gSystem -> Exec("chmod a+x *sh ../*sh");

  return 0;
}
